# `@w-sim/solvers-path-experiment`

Deterministic **path-experiment** runner for W-Sim.

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |
| **maturity** | `smoke` (scaffold + bounds + capability/retry + production budgets / claim-loop + checkpoint golden + RK4 photo extract + photo KPI golden / O2 residual + multi-dataset calibration + uncertainty sampling + ensemble quantiles + coverage + CRPS + interval-score + DSS + PIT + quadratic-score + logarithmic-score + spherical-score + energy-score + variogram-score + multivariate-DSS + average-rank + reliability-diagram + sharpness + discrimination + skill + resolution + decomposition + ROC/AUC+Brier + ignorance + calibration-slope + reliability-slope-skill + Brier-slope dual + log-slope dual + Brier-ignorance dual + triple skill + quadruple skill + quintuple skill + sextuple skill residual; not engineering-complete) |
| **JobKind** | `path-experiment` from `@w-sim/contracts` (`BUILTIN_JOB_KINDS`) — no local raw-string duplicate |
| **capability id** | `w-sim-path-experiment-cpu` |
| **method** | `path-replay-v1` |
| **precision** | float64 (digest / counters) |
| **targets** | node CPU reference |

## What this package does

- Admits `path-experiment` jobs via the shared `JobRunner` shape (`canRun` + `run`).
- Executes an ordered, **bounded** step graph (from `spec.experiment.steps` or the built-in multi-step smoke fixture).
- Emits stable `JobProgress` step events and per-step artifacts.
- Supports **cancellation** (`AbortSignal`) between steps and **checkpoint / resume**.
- Retains partial artifacts on failure; failure provenance includes path version, step, attempt, and input digest.
- Retry / resume cannot re-apply a step’s externally visible result twice (idempotent step application).
- **Capability** advertisement (`PATH_EXPERIMENT_HOST_CAPABILITY` / `PathModelCapability`) for host matching.
- **Resource estimates** (`estimatePathResources`) for pre-claim placement — smoke and **production** tiers.
- **Host-level retry policy** (`shouldHostRetry` / `classifyPathFailure`) beyond step-apply idempotency.
- **Claim-loop smoke** (host double + contracts `applySettlement`) proves one successful path run settles exactly once.

## Photosensitization RK4 (S20h + S20i + S20j + S20k + S20l + S20m + S20n + S20o + S20p + S20q + S20r + S20s + S20t + S20u + S20v + S20w + S20x + S20y + S20z + S20aa + S20ab + S20ac + S20ad + S20ae + S20af + S20ag + S20ah + S20ai + S20aj + S20ak + S20al + S20am + S20an + S20ao residual)

Package-local float64 Jablonski kernel for `experiment.model.id === 'photosensitization-rk4'`:

- `defaultPhotoParams` / `integratePhotosensitization` / `steadyState` / `computePhotoKineticKpis`
- Fixture: `buildPhotosensitizationJobSpec()` (excitation → isc → ros, pathScore=6)
- Model capability: `PHOTOSENSITIZATION_RK4_MODEL_CAPABILITY` (`analyses: ['calibration','uncertainty']`)
- Gate: end-state vs analytic ss under `PHOTO_SS_REL_TOLERANCE` (1e-3); conservation 1e-12
- **S20i**: sealed KPI golden `fixtures/photosensitization-rk4.golden.json` + hypoxia O2 residual (`PHOTO_HYPOXIA_O2=0.05` collapses Type II below Type I); runner summary exports full branch KPIs (`branchTypeII` / `branchTypeI` / `branchDeactivation`) and `S0`/`S1`
- **S20j**: multi-dataset calibration golden `fixtures/photosensitization-rk4-multidataset.golden.json` (hypoxia/midoxia/normoxia/hyperoxia + high-substrate); `matchPhotoMultiDatasetGolden` / `o2TypeIIMonotonicResidual` / `hyperoxiaBranchResidual` / `highSubstrateBranchResidual`
- **S20k**: uncertainty sampling golden `fixtures/photosensitization-rk4-uncertainty.golden.json` (seeded ensemble mean/std); `uncertaintySpreadResidual`; runner `uncMean*` / `uncStd*`
- **S20l**: ensemble quantiles on the same golden (p05/p50/p95 per channel); `uncertaintyQuantileResidual`; runner `uncP05*` / `uncP50*` / `uncP95*` for T1 and Type II branch
- **S20m**: own-sample [p05,p95] coverage residual (`uncertaintyCoverageResidual` / `computePhotoUncertaintyCoverage`); runner `uncCoverageT1` / `uncCoverageBranchTypeII` / `uncNominalInsideBranchTypeII`
- **S20n**: empirical CRPS residual vs nominal (`uncertaintyCrpsResidual` / `computePhotoUncertaintyCrps` / `empiricalCrps`); runner `uncCrpsT1` / `uncCrpsBranchTypeII` / `uncMeanCrps`
- **S20o**: Winkler interval-score residual on [p05,p95] vs nominal (`uncertaintyIntervalScoreResidual` / `computePhotoUncertaintyIntervalScore` / `winklerIntervalScore`); runner `uncIntervalScoreT1` / `uncIntervalScoreBranchTypeII` / `uncMeanIntervalScore`
- **S20p**: Dawid–Sebastiani DSS residual of mean/std vs nominal (`uncertaintyDssResidual` / `computePhotoUncertaintyDss` / `dawidSebastianiScore`); runner `uncDssT1` / `uncDssBranchTypeII` / `uncMeanDss`
- **S20q**: mid-rank PIT residual vs nominal (`uncertaintyPitResidual` / `computePhotoUncertaintyPit` / `ensemblePit`); runner `uncPitT1` / `uncPitBranchTypeII` / `uncMeanAbsPitDeviation`
- **S20r**: Gaussian quadratic-score residual of mean/std vs nominal (`uncertaintyQuadraticScoreResidual` / `computePhotoUncertaintyQuadraticScore` / `gaussianQuadraticScore`); runner `uncQuadraticScoreT1` / `uncQuadraticScoreBranchTypeII` / `uncMeanQuadraticScore`
- **S20s**: Gaussian logarithmic-score residual of mean/std vs nominal (`uncertaintyLogScoreResidual` / `computePhotoUncertaintyLogScore` / `gaussianLogScore`); runner `uncLogScoreT1` / `uncLogScoreBranchTypeII` / `uncMeanLogScore`
- **S20t**: Gaussian spherical-score residual of mean/std vs nominal (`uncertaintySphericalScoreResidual` / `computePhotoUncertaintySphericalScore` / `gaussianSphericalScore`); runner `uncSphericalScoreT1` / `uncSphericalScoreBranchTypeII` / `uncMeanSphericalScore`
- **S20u**: Multivariate energy-score residual of KPI ensemble vector vs nominal (`uncertaintyEnergyScoreResidual` / `computePhotoUncertaintyEnergyScore` / `empiricalEnergyScore`); 1D channel ES = CRPS; runner `uncEnergyScore` / `uncEnergyScoreBranchTypeII` / `uncMeanChannelEnergyScore`
- **S20v**: Multivariate variogram-score residual of KPI ensemble vector vs nominal (`uncertaintyVariogramScoreResidual` / `computePhotoUncertaintyVariogramScore` / `empiricalVariogramScore`, p=`PHOTO_UNCERTAINTY_VARIOGRAM_ORDER=0.5`); runner `uncVariogramScore` / `uncVariogramMeanEnsemblePairDiff` / `uncVariogramTypeIIT1PairResidualSq`
- **S20w**: Multivariate Dawid–Sebastiani residual of KPI ensemble mean/cov vs nominal (`uncertaintyMultivariateDssResidual` / `computePhotoUncertaintyMultivariateDss` / `multivariateDawidSebastianiScore`, ridge=`PHOTO_UNCERTAINTY_MULTIVARIATE_DSS_RIDGE=1e-12`); runner `uncMultivariateDss` / `uncMultivariateDssMahalanobisSq` / `uncMultivariateDssLogDet`
- **S20x**: Multivariate average-rank residual of KPI ensemble vs nominal (`uncertaintyAverageRankResidual` / `computePhotoUncertaintyAverageRank` / `ensembleAverageRank` / `averagePreRank` / `midRankAmong`); runner `uncAverageRank` / `uncAverageRankAbsDev` / `uncMeanUnivariatePit`
- **S20y**: LOO mid-rank PIT reliability-diagram residual (`uncertaintyReliabilityResidual` / `computePhotoUncertaintyReliability` / `reliabilityDiagram` / `leaveOneOutPits`); runner `uncReliabilityEce` / `uncReliabilityMaxBinMassDev` / `uncMeanLooPit`
- **S20z**: Prediction-interval / ensemble-spread sharpness residual (`uncertaintySharpnessResidual` / `computePhotoUncertaintySharpness` / `ensembleSharpness`); runner `uncMeanIntervalWidth` / `uncMeanEnsembleStd` / `uncSharpness`
- **S20aa**: Two-group LOO mid-rank PIT discrimination residual (`uncertaintyDiscriminationResidual` / `computePhotoUncertaintyDiscrimination` / `medianSplitIsUpper` / `twoGroupMeanAbsDiff`); runner `uncDiscrimination` / `uncDiscriminationSplitSep` / `uncDiscriminationSplitMeanLooPitLower`
- **S20ab**: LOO CRPS skill residual vs σ=0 nominal climatology (`uncertaintySkillResidual` / `computePhotoUncertaintySkill` / `leaveOneOutMeanCrps` / `climatologyMaeVsNominal` / `crpsSkillScore`); runner `uncCrpsSkill` / `uncCrpsSkillTypeII` / `uncMeanLooCrps`
- **S20ac**: Gneiting-style two-group CRPS resolution / η² MI-lite residual after median split (`uncertaintyResolutionResidual` / `computePhotoUncertaintyResolution` / `twoGroupResolutionStats`); runner `uncCrpsResolution` / `uncCrpsResolutionTypeII` / `uncMeanEtaSquared`
- **S20ad**: Murphy CRPS three-term decomposition residual after median split (`uncertaintyDecompositionResidual` / `computePhotoUncertaintyDecomposition` / `crpsDecompositionIdentity`: reliability + resolution − uncertainty ≈ 0); runner `uncCrpsReliability` / `uncCrpsUncertainty` / `uncCrpsDecompIdentity`
- **S20ae**: ROC/AUC + binary Brier residual vs Type II median-split event (`uncertaintyRocBrierResidual` / `computePhotoUncertaintyRocBrier` / `rocAuc` / `binaryBrierScore` / `brierSkillScore`); runner `uncRocAuc` / `uncRocAucTypeII` / `uncBrierSkillTypeII`
- **S20af**: Binary ignorance residual vs Type II median-split event (`uncertaintyIgnoranceResidual` / `computePhotoUncertaintyIgnorance` / `binaryIgnoranceScore` / `ignoranceSkillScore`); runner `uncMeanIgnorance` / `uncIgnoranceTypeII` / `uncIgnoranceSkillTypeII`
- **S20ag**: Calibration slope/intercept residual vs Type II median-split event (`uncertaintyCalibrationResidual` / `computePhotoUncertaintyCalibration` / `calibrationSlopeIntercept`); runner `uncCalibrationSlopeTypeII` / `uncCalibrationInterceptTypeII` / `uncMeanCalibrationSlope`
- **S20ah**: Reliability slope skill residual after S20ag (`uncertaintyReliabilitySkillResidual` / `computePhotoUncertaintyReliabilitySkill` / `slopeSkillScore` / `interceptSkillScore` / `reliabilitySkillScore` / `reliabilityRegressionR2`); runner `uncSlopeSkillTypeII` / `uncReliabilitySkillTypeII` / `uncReliabilityR2TypeII`
- **S20ai**: Brier skill vs slope skill dual residual after S20ah (`uncertaintyBrierSlopeDualResidual` / `computePhotoUncertaintyBrierSlopeDual` / `dualSkillScore` / `skillAbsDiff`); runner `uncDualSkillTypeII` / `uncBrierSlopeAbsDiffTypeII` / `uncMeanDualSkill`
- **S20aj**: Logarithmic skill vs slope skill dual residual after S20ai (`uncertaintyLogSkillDualResidual` / `computePhotoUncertaintyLogSkillDual`; reuses `dualSkillScore` / `skillAbsDiff`); runner `uncLogDualSkillTypeII` / `uncIgnoranceSlopeAbsDiffTypeII` / `uncMeanLogDualSkill`
- **S20ak**: Brier skill vs ignorance skill dual residual after S20aj (`uncertaintyBrierIgnoranceDualResidual` / `computePhotoUncertaintyBrierIgnoranceDual`; reuses `dualSkillScore` / `skillAbsDiff`); runner `uncBrierIgnDualSkillTypeII` / `uncBrierIgnoranceAbsDiffTypeII` / `uncMeanBrierIgnDualSkill`
- **S20al**: Brier/ignorance/slope triple skill residual after S20ak (`uncertaintyTripleSkillResidual` / `computePhotoUncertaintyTripleSkill` / `tripleSkillScore` / `skillMaxAbsDiff` — dual/skill expand of S20ai–S20ak pairwise duals); runner `uncTripleSkillTypeII` / `uncTripleSkillMaxAbsDiffTypeII` / `uncMeanTripleSkill`
- **S20am**: Brier/ignorance/slope/AUC quadruple skill residual after S20al (`uncertaintyQuadSkillResidual` / `computePhotoUncertaintyQuadSkill` / `quadSkillScore` / `aucSkillScore` / `skillMaxAbsDiff4` — uncertainty skill expand of S20al triple + ROC AUC ranking skill); runner `uncQuadSkillTypeII` / `uncQuadSkillMaxAbsDiffTypeII` / `uncMeanQuadSkill`
- **S20an**: Brier/ignorance/slope/AUC/intercept quintuple skill residual after S20am (`uncertaintyQuintSkillResidual` / `computePhotoUncertaintyQuintSkill` / `quintSkillScore` / `skillMaxAbsDiff5` — uncertainty skill expand of S20am quad + intercept skill from S20ah); runner `uncQuintSkillTypeII` / `uncQuintSkillMaxAbsDiffTypeII` / `uncMeanQuintSkill`
- **S20ao**: Brier/ignorance/slope/AUC/intercept/R² sextuple skill residual after S20an (`uncertaintySextSkillResidual` / `computePhotoUncertaintySextSkill` / `sextSkillScore` / `r2SkillScore` / `skillMaxAbsDiff6` — uncertainty skill expand of S20an quint + OLS reliability R² skill from S20ah); runner `uncSextSkillTypeII` / `uncSextSkillMaxAbsDiffTypeII` / `uncMeanSextSkill`

## What it does not do (yet)

- Full engineering maturity (product multi-lab golden, GPU/WebGPU parity, full Bayesian/UQ product path / MCMC posterior).
- Tuanliu product Host HTTP claim+lease+settlement e2e (package has S20d/S20e smokes).
- Settlement **ownership** (Host `applySettlement` stays outside the package; package only returns settlement-compatible results).

## Bounds (defaults)

| Cap | Smoke | Production | Enforcement |
|-----|-------|------------|-------------|
| maxSteps | 32 | 256 | Admission (`run.maxSteps` + declared plan length) |
| maxFanOut | 4 | 16 | Admission (max edges on any step) |
| maxArtifactBytes | 256 KiB | 4 MiB | During execution (cumulative path-step artifacts) |
| maxWallTimeMs | 5000 (`smokeBudget`) | 60000 (`productionBudget`) | During execution (between steps); retryable |
| maxMemoryMb | 256 (`smokeBudget`) | 2048 (`productionBudget`) | Documented + `estimatePathResources({ tier })` |

Use `PRODUCTION_PATH_BOUNDS` / `estimatePathResources(spec, { tier: 'production' })` for production placement. Domain validation (`validatePathExperimentDomain`) rejects bad experiment shape before any step runs. See [`docs/solvers/path-experiment.md`](../../docs/solvers/path-experiment.md).

## Docs

- Package standard: [`docs/SOLVER_PACKAGE_STANDARD.md`](../../docs/SOLVER_PACKAGE_STANDARD.md)
- Golden / lifecycle harness: [`docs/solvers/golden-conformance.md`](../../docs/solvers/golden-conformance.md) · cases under `packages/solver-conformance/cases/path-experiment/` · `npm run test:golden -w @w-sim/solvers-path-experiment`
- Definition of Done: [`docs/SOLVER_DEFINITION_OF_DONE.md`](../../docs/SOLVER_DEFINITION_OF_DONE.md)
- Family notes: [`docs/solvers/path-experiment.md`](../../docs/solvers/path-experiment.md)

## Smoke

```bash
npm test -w @w-sim/solvers-path-experiment
# or from repo root:
npm test
```
