# `@w-sim/fem-import`

The package parses an explicit subset of Abaqus/CalculiX `.inp` decks and maps
admitted cases to W-Sim structural `JobSpecV1` values. It does not run a solver.
Unsupported solution-affecting cards fail closed in `diagnostics`.

`*NSET` and `*ELSET` support explicit members and `GENERATE` ranges with
positive safe-integer first/last/step values; the last label must be reached
exactly by the step. Generated members share a cumulative limit of 1,048,576.
Nested references resolve recursively within the same kind (`NSET` to `NSET`,
`ELSET` to `ELSET`); undefined, cyclic, cross-kind, or nonexistent numeric
members fail closed. Resolution is bounded by 4,194,304 work units, reference
depth 256, and 1,048,576 resolved members. `*NSET, ELSET=<name>` derives a
node set from the referenced ELSET's element connectivity as it exists at
that card's declaration; later ELSET additions do not change the derived set.
This form cannot include data lines or `GENERATE`.

## Part and assembly subset

Alongside legacy flat decks, the importer accepts one named `*PART`, one
`*ASSEMBLY`, and exactly one `*INSTANCE` in that assembly referencing that
part. The supported mesh, sets, material assignment, and sections remain the
same strict subset described below. The instance may omit placement data or
provide one three-number translation row; the translation is applied to node
coordinates when the instance is flattened into the imported mesh. Rotation is
not supported.

Assembly-level `*NSET` and `*ELSET` cards may select numeric labels from the
sole instance with `INSTANCE=<instance-name>`. Deterministic part- or
instance-qualified set references are accepted only when they resolve
unambiguously. Label and set-name collisions, ambiguous scopes, and references
that cannot be flattened to the single-instance numeric-label representation
fail closed.

Multiple parts or instances, nested assemblies, imported instances, mesh
overrides at the instance level, rotations or other placement data, and
coupling or constraint definitions are unsupported and fail closed. This is a
bounded flattening path, not general Abaqus assembly support. Abaqus defines part
geometry and labels locally and positions instances in assembly coordinates;
assembly definitions can also contain multiple positioned instances. See
[Dassault Systèmes' Assembly Definition](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEMODRefMap/simamod-c-partassy.htm)
and [parts, instances, and assemblies](https://docs.software.vt.edu/abaqusv2025/English/SIMACAECAERefMap/simacae-c-asmconcinstancesrelationship.htm).

The structural subset includes `*DLOAD` with `GRAV` on a named, explicit
`ELSET` and uniform element-face pressure on C3D4, C3D5, and C3D8 elements in a
single static step. Pressure targets may be an element label or resolved
`ELSET`. Pressure is integrated on the original Abaqus face before any
tetrahedral approximation; positive values act inward. Triangular faces are
mapped exactly. Quadrilateral faces are admitted only when planar
parallelograms (constant Jacobian), so equal face-node shares preserve exact
resultant and moment. Warped/non-parallelogram, degenerate, and inverted loaded
elements fail closed. Duplicate pressure rows on one element face and modal
pressure are unsupported. `*DSLOAD`, `*SURFACE`, amplitudes, nonlinear geometry,
and other pressure forms remain unsupported.

`*ELEMENT, TYPE=C3D5` is an importer-only compatibility path. Each five-node
pyramid is represented by two linear tet4 elements split across base diagonal
0–2. This preserves the chosen piecewise-linear geometric partition when both
tetrahedra are valid, but it approximates the C3D5 element stiffness and
interpolation; it is not the native pyramid formulation. Degenerate or
inconsistently oriented splits fail closed. C3D5 gravity is distributed over
the two tet4 volumes using the same constant-acceleration, positive-density
rule as the other imported solids. Uniform pressure supports C3D5 P2–P5
triangular faces and P1 base quadrilateral under the same face-geometry rules
above. This scoped importer support does not mean the CalculiX solver itself
supports C3D5, and it does not establish full Abaqus/vendor compatibility or
solver parity.

Gravity requires one assigned isotropic material with positive `*DENSITY`;
it is converted to equivalent tet4 nodal forces using the deck's assumed SI
units (`m`, `kg/m³`, `m/s²`, `N`). Direction components are normalized before
multiplying by acceleration magnitude, so `0, 0, -2` means negative z. The
importer rejects zero/non-finite directions, overlapping GRAV records,
amplitude options, blank whole-model targets, and other distributed load
types.

## Single-file import

Use `inpTextToJobSpec(text, options?)` when the complete deck is already in one
string. This API continues to report `*INCLUDE` as unsupported because it has
no file resolver.

## Multi-file import

For decks with `*INCLUDE`, pass the root path and every available file as
bundle-relative paths. The package performs no filesystem reads:

```ts
import { inpFilesToJobSpec } from '@w-sim/fem-import'

const result = inpFilesToJobSpec('model/main.inp', {
  'model/main.inp': mainDeckText,
  'model/mesh/mesh.inc': meshDeckText,
  'model/nodes.inc': nodeDeckText,
  'model/material.inc': materialDeckText,
  'model/loads.inc': loadDeckText,
})

if (!result.ok) {
  // Render each diagnostic's level, path, and message.
} else {
  const jobSpec = result.spec
}
```

`parseInpDeckFiles(entryPath, files)` is available when callers need the
`FemCaseIR` without producing a `JobSpec`. Both APIs return the existing
`FemDiagnostic[]` structure (`level`, `path`, `message`). Diagnostics from
included cards identify the original relative file and line, for example
`model/nodes.inc:3 (*NODE)`.

Include paths resolve relative to the including file. `..` references work
while the normalized path stays inside the supplied bundle root. Absolute
paths, root escapes, missing files, malformed include cards, cycles, nesting
over 16, more than 256 includes, or expanded content over 1,048,576 characters
fail closed. Only the currently supported importer cards are accepted after
expansion; include resolution does not widen the FEM analysis or element
subset.

The multi-file functions are additive package exports. Existing
`parseInpDeck(text)` and `inpTextToJobSpec(text, options?)` behavior is
unchanged.
