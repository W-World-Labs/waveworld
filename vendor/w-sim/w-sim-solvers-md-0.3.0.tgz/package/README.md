# `@w-sim/solvers-md`

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |

Smoke: 2-body Lennard-Jones analytic pair. See `docs/solvers/md.md`.
