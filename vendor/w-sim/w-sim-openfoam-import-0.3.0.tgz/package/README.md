# OpenFOAM importer

`parseFoamCase` converts case files into an OpenFOAM IR. The mappers produce
W-Sim JobSpecs for the existing CPU and CUDA LBM paths; they do not run a
solver. Unsupported case data fails closed with diagnostics.

The dictionary reader supports bounded resolution of quoted, case-local
`#include` and `#includeIfPresent` directives using files in the supplied case
map. A missing `#include` target is an error; a missing `#includeIfPresent`
target is skipped. Present targets are expanded in place, relative to the
including file. Expansion is limited to depth 16, 128 distinct targets, and
4 MiB of expanded text. The small static example in
[`fixtures/optional-includes.json`](./fixtures/optional-includes.json) shows a
present and a missing optional fragment.

This is source-level, preprocessing-only text handling. It is not full
OpenFOAM preprocessing or solver support: `#includeEtc`, macro and function
expansion, environment substitution, and other directive forms are not
implemented. Parsing a case does not certify that a solver can run it, and
the mapper still rejects unsupported mesh and physics features. This behavior
is not a deployed or pinned OpenFOAM capability and does not claim parity with
OpenFOAM or vendor implementations.

For velocity `U`, `fixedValue` accepts a uniform vector. `uniformFixedValue`
also accepts the static Function1 form `uniformValue constant (Ux Uy Uz)` and
maps it to the same inlet behavior. Time-varying tables, expressions, malformed
vectors, and non-finite components remain unsupported. Other inlet, outlet,
mesh, and physics limits are unchanged.
