# Embedded WASM runtime notices

W-Sim's own implementation is MIT licensed; see LICENSE. The embedded
`dist/wasm-kernel.js` payload also contains Rust runtime code. These notices
apply to those upstream portions, rather than assigning their ownership to W-Sim.

The committed WASM contains Rust core source paths at compiler revision
`ac68faa20c58cbccd01ee7208bf3b6e93a7d7f96` (Rust 1.96.0), matching the
public CI toolchain. Its source hash marker covers the W-Sim kernel inputs;
that marker alone is not a bit-for-bit reproducibility claim.

Original notices are reproduced without modification:

| File | Upstream source and scope |
| --- | --- |
| `licenses/rust/LICENSE-MIT` and `licenses/rust/COPYRIGHT` | [Rust 1.96.0](https://github.com/rust-lang/rust/tree/1.96.0), Rust core and project copyright; MIT option |
| `licenses/compiler-builtins/LICENSE.txt` | [Rust 1.96.0 compiler-builtins](https://github.com/rust-lang/rust/blob/1.96.0/library/compiler-builtins/LICENSE.txt), compiler runtime, including MIT AND Apache-2.0 WITH LLVM-exception terms |
| `licenses/libm/LICENSE.txt` | [Bundled libm](https://github.com/rust-lang/rust/blob/1.96.0/library/compiler-builtins/libm/LICENSE.txt), math routines and original per-project credits |
| `licenses/compiler-rt/CREDITS.TXT` | [Compiler-rt credits](https://github.com/rust-lang/llvm-project/blob/1cb4e3833c1919c2e6fb579a23ac0e2b22587b7e/compiler-rt/CREDITS.TXT), at the LLVM revision pinned by Rust 1.96.0 |

The compiler-builtins and libm notices conservatively accompany the runtime
without asserting that every upstream routine is linked. No Rust compiler,
Cargo registry source tree or external engine data is bundled.
