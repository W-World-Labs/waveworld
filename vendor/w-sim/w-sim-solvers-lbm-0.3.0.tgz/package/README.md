# `@w-sim/solvers-lbm`

The current product surface is `@w-sim/solvers-lbm/d3q19`: model preparation,
Rust/WASM voxelization and the shared ABI11 numerical core. Native consumers link
[`w-sim-kernels`](../../crates/w-sim-kernels/README.md). Isothermal D3Q19/fan flow
also runs through the WebGPU solver. Thermal jobs use the conservative energy
discretization in Rust/WASM or the explicit FP32 WebGPU backend described below:
uploaded solid materials, their thermal capacity/conductivity and total power,
or a fixed-temperature wall. The old D3Q7 path has been removed.
See the [ABI layout](../../crates/w-sim-kernels/wasm/README.md) and core README for
physical inputs, strict dt/viscosity admission, energy accounting and validation
limits. This is not an engineering-certified whole-machine cooling solver.

Product preparation defaults to `parameters.viscosityMode='physical'`: it
preserves the requested base viscosity and rejects a grid/time scale that cannot
resolve `tau >= 0.505`, reporting the maximum supported Reynolds number and the
required characteristic cell count. Only an explicit `stabilized-preview` may
raise viscosity. Its result is a changed-viscosity flow preview, with
`derived.requestedViscosityM2s`, `simulatedViscosityM2s`, `viscosityMode` and both
requested/simulated Reynolds numbers saved for inspection. Smagorinsky eddy
viscosity cannot restore the lost Reynolds similarity. Thermal always requires
physical mode.

For fixed-temperature thermal jobs without an explicit `dtSeconds`, preparation
starts from reference lattice speed 0.06 and increases the time step only as
needed to resolve `tau >= 0.505`. It still requires reference lattice speed
below 0.2 and never changes physical viscosity. If no time step satisfies both
limits, admission reports the incompatible time-step bounds and required model
cell count. Explicit time steps remain unchanged; solid-power jobs retain their
default `dtSeconds=1e-4`. These checks establish numerical admission, not
convergence or validated cooling performance.

`prepareProductLbmUnits(spec, characteristicLength)` resolves the same physical
scales used by lattice preparation without voxelization. A requested duration
maps to `ceil(durationSeconds / units.dt)` steps; playback speed never changes
the physical time step.

With nonempty `outputs.fields`, `outputs.fieldFrames` requests 1..16 actual field
snapshots. Omitted/1 preserves final-only output. `lbmFieldSampleSteps` selects
uniformly spaced integer steps including step 1 and the final step when multiple
frames fit, bounded by completed steps, 32 MiB per field file and 256 MiB in total.
Early convergence saves scheduled frames already reached and the actual final
state exactly once. `runBatchLbm` awaits `onDisplaySnapshot` per frame without
extra solver steps or changing force-history sampling. Executors must advertise
`lbm-field-history-v1` for requests greater than one and report it in `derived`;
artifact refs may carry the corresponding `step`. Existing final-only artifacts
remain readable. Each frame is a sampled state; this is not a solver checkpoint
or an interpolation of the physics between saved states.

`outputs.fields: ['pressure']` (also combinable with velocity/vorticity/temperature)
requests the actual current-population density pressure. It adds the conditional
`lbm-pressure-field-v1` requirement and saves that marker plus
`derived.pressureScalePa = density * (dx/dt)^2` in the result. A snapshot with
`hasPressure: true` appends lattice gauge pressure after the existing channels.
Thus stride 3 can be either historical thermal data or isothermal pressure;
readers must inspect `hasPressure`, not infer temperature from stride alone.
Thermal pressure has stride 4. The byte budget includes every requested channel;
there is no implicit pressure computation when it was not requested.
The pressure definition, gauge reference and force/stress limits are documented
in the [core](../../crates/w-sim-kernels/README.md#lbm-pressure-display).

`W_SIM_GPU_PRESSURE_ONLY=1` selects the pressure tests in the existing opt-in
`scripts/check-lbm-thermal-gpu.mjs` harness. It requires the documented external
Playwright module and current contracts/LBM build, installs no dependencies,
and checks 84-cell thermal/isothermal fixtures for zero or three solver steps.
Dyadic pressure values are exact; evolving pressure is compared to an
independent f64 sum with a FP32 operation-count error bound. Original scientific
fields, force/mass/heat accounts and display prefixes must remain bit-identical
when pressure output is toggled. This is a short output check, not a full
10-second physical simulation or a hardware-performance benchmark.

Model force is relative to the fixed static `rho_ref=1` ambient pressure:
`2*c_q*(post_q - f32(w_q))` on each existing model bounce-back link. Rust/WASM
and WebGPU use this same convention and advertise `lbm-gauge-force-v1`; new LBM
specs explicitly request it, and capability matching derives it even if a caller
omits requirements. No local-density or inlet-equilibrium subtraction is made.
This removes an unbalanced ambient load on a ground-contacting model while
preserving physical pressure differences, fan and thermal effects. Closed
immersed surfaces have zero net reference load. See the
[core derivation and reference](../../crates/w-sim-kernels/README.md). The gauge
correction preserves force unit conversion; older raw-force results require
their original interpretation.

Both x boundaries use all 19 current-stream inner populations and bare moments.
The inlet is `feq(rho_inner,u_target)+(f_inner-feq(rho_inner,u_inner))`, including
prescribed deterministic velocity noise; the outlet remains
`feq(1,u_inner)+(f_inner-feq(rho_inner,u_inner))`. Product/GPU preparation and
the shared kernel reject solid immediate donors through `validateLbmOpenBoundaries`;
reduce the model/domain ratio or adjust geometry instead of clipping it.
ABI9 and `lbm-nee-inlet-v1` distinguish the inlet from the old equilibrium reset.
Every LBM job requires the feature and actual results report 1 in `derived`,
alongside the existing outlet/gauge features. The package shell remains a stub.

Boundary reconstruction can exchange mass even at zero inlet speed. The LBM
thermal inlet still thermostats its entire cell to ambient; mass replacement
and thermostat heat are included in the boundary-energy ledger. See the
[core derivation and original-method scope](../../crates/w-sim-kernels/README.md).
Side walls remain impermeable slip/no-slip walls. Tiny analytic/parity tests
do not certify non-reflecting far fields, vehicle drag or high-Reynolds accuracy.
The opt-in GPU inlet check asserts every population against bit-identical
native/WASM with absolute epsilon `2e-7`, and the native/WASM density against
the independent ideal value with the same epsilon. For the GPU f64 sum of 19
readback f32 populations, the triangle-inequality budget is `(19+1)*epsilon`.
Each backend must also match its own current donor density within `2e-7`;
prescribed velocity and shear retain their separate `2e-7` gates. This separates
upstream FP32 population rounding from an incorrect boundary reconstruction;
it is not a blanket relaxation of field tolerances or a solver accuracy claim.


Isothermal `refreshMacros` also validates the completed populations, positive
finite density and finite lattice speed below 0.2. It reuses the existing
64-lane force scratch/reduction and `forceSums.w` error flag; the same force
readback rejects invalid fields even when no display fields were requested.
No values are clamped to manufacture stability. Thermal execution retains its
existing atomic error path. A fault-injection regression clears an outlet inner
node after streaming; this demonstrated a former false success for zero-force
readback, not a demonstrated instability from normal product inputs.
This adds population/field checks, seven workgroup barriers and one read/write
of the existing force partial per workgroup to the existing macros dispatch.
The reduction uses 2 KiB of existing workgroup scratch; there is no additional
global buffer, dispatch or readback. Its timing impact depends on the device;
this is a correctness guard, with no performance improvement claimed.

Zero inlet has no inlet-based drag/lift coefficient: batch results omit Cd/Cl
and reject Cd-based stopping, while preserving `dragN`, `liftN`, `sideN` history
in newtons. A Cd-based stopping request returns the actual sampled history even
when `outputs.history=false`, so Hosts can verify its stopping window. Without
a stopping request, `outputs.history` controls whether history is returned.
For a stationary isothermal case, the time step uses a diffusion scale with
`tau=0.8`, both Reynolds numbers are zero, and `uLattice` remains a nonzero display
reference rather than an imposed inlet.

The extraction/fixture notes below record earlier staged work; they do not
describe the current shared product kernel ownership.


Package **shell** for the production LBM fluid kind (`lbm-d3q19`).

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track · seam #9 (historical internal reference) · inventory #17) |
| **maturity** | `smoke` (layout + stub runner only; **not** engineering-complete) |
| **JobKind** | `lbm-d3q19` from `@w-sim/contracts` (`BUILTIN_JOB_KINDS`) — no local raw-string duplicate |
| **method** | `lbm-d3q19-stub` (not-implemented until extract) |
| **precision** | float32 (matches WaveWorld WebGPU path; documented for future extract) |
| **targets** | node + browser planned; shell admits kind only |
| **Live CFD path (WW)** | `modules/tuanliu/src/lib/cfd/d3q19-solver.ts` — protected by parity manifests; **RB-LBM-0** until extract |

## What this package does today

- Registers `SOLVER_PACKAGE_META` for discovery / kind-matrix / `check:solvers`.
- Exposes a **stub** `JobRunner` (`createLbmJobRunner`) that admits `lbm-d3q19` via `canRun` and **rejects** `run` with `SolverNotImplementedError`.
- **S19a** analytic Poiseuille / BGK τ helpers (`poiseuille.ts`).
- **S19b** headless **float64 D2Q9 BGK lid-driven cavity** (`d2q9-cavity.ts`) with bounded mass residual + steady velocity KPI — CPU reference only; **RB-LBM-0** still holds (no WW `cfd/**` move).
- **S19be** force-channel eng dual residual after S19bd (`d3q19-bgk-force-channel.ts`): means dual residual matrix + cross↔matched GM dual residual + means dual residual max extract (dual residual-matrix packaging of S19bd dual extract triad; pure KPI dual expand; smoke ≠ eng DoD; high-Re WebGPU host still blocked).
- **S19bd** force-channel eng dual residual after S19bc (`d3q19-bgk-force-channel.ts`): matched means residual matrix + cross↔matched AM dual residual + cross↔matched HM dual residual (AM/GM/HM residual-matrix dual packaging after S19bc; pure KPI dual expand; smoke ≠ eng DoD; high-Re WebGPU host still blocked).
- **Does not** call settlement, Host DB, billing, or WaveWorld paths.
- Production D3Q19 WebGPU path remains WaveWorld `modules/tuanliu/src/lib/cfd/**` until extract (#19 / EXTRACTION_PLAN §8) after parity.

## Parity fixtures (S17c + S17e recording)

Under [`fixtures/`](./fixtures/):

| id | intent | status |
|----|--------|--------|
| `lbm-p1-empty-channel` | empty freestream smoke | input + tolerances sealed; **no** `expected.json` |
| `lbm-p2-bluff-cube` | cube bluff-body force baseline | input + tolerances sealed; **no** `expected.json` |

Loader/validate: `loadParityFixtureManifest` / `validateParityFixtureManifest` (see `src/fixtures.ts`). Tests assert both load cleanly and that field goldens are **not** fabricated pre-extract.

**Recording harness (S17e):** `recordParityFixtures` + `defaultProbeBWebgpuNodeHost` (`src/recording.ts`). Writes `expected.json` **only** when named profile **B-webgpu-node** (or injected WebGPU device) is available, a numerical `runFixture` is supplied, and `write: true`. If the device is absent, the suite **skips** without fabricating goldens. Shell without `runFixture` **refuses** (physics not extracted).

## What it does not do (yet)

- D3Q19 collide/stream, units, voxelizer, or WebGPU kernels (still WW).
- Committed real `expected.json` field/KPI baselines (harness ready; needs extract + B-webgpu-node host run).
- Measured B-webgpu-node bench table.
- Production agent dispatch wiring.

## Go / no-go (S17d + S9 / Gitea #9)

Formal EXTRACTION_PLAN §7 checklist + decision: [`docs/solvers/lbm-extraction.md` §11–§14](../../docs/solvers/lbm-extraction.md).

| Scope | Verdict |
|-------|---------|
| §7 readiness / architecture close-out (#9) | **GO** (inventory + shell + manifests + gates + re-export strategy; no further architecture investigation) |
| Physical CFD source move (§8 / #19) | **NO-GO** — **RB-LBM-0** in force until real P1/P2 goldens + measured B-webgpu-node bench |
| Fabricated field goldens | **Forbidden** |
| Bundle / lifecycle / ownership gates | Documented in extraction doc **§12** |
| Tuanliu re-export window | Documented in extraction doc **§13** (P0–P3; no deletes under RB-LBM-0) |

## Smoke budget

| maxWallTimeMs | maxMemoryMb |
|---------------|-------------|
| 5000          | 256         |

## Docs

- Extraction readiness + go/no-go: [`docs/solvers/lbm-extraction.md`](../../docs/solvers/lbm-extraction.md)
- Epic plan §7/§8: [`docs/EXTRACTION_PLAN.md`](../../docs/EXTRACTION_PLAN.md)
- Package standard: [`docs/SOLVER_PACKAGE_STANDARD.md`](../../docs/SOLVER_PACKAGE_STANDARD.md)
- Matrix plan issue 4 / Gitea #17

## Force accumulation and sampling

The flow and thermal GPU paths use the same 64-lane workgroup reduction for
model link forces. Each 4×4×4 group owns one cumulative `vec4<f32>` containing
xyz force and an error flag. Padding and solid lanes contribute zero and still
reach every barrier. Ground and external side-wall impulse remain excluded.
The old i32×1e6 atomic force path is removed: valid sums can exceed 2147 lattice
units and small contributions are no longer quantized to 1e-6.

Force buffers use 16 bytes per workgroup (about 0.25 bytes per grid cell, plus
an equally sized staging buffer). `readForces` copies and clears the GPU sums in
one command submission, then adds the partials in fixed order with JS Number
arithmetic. Steps submitted while the snapshot maps belong to the next sample.
There is no new GPU pass or per-step readback. Nonfinite or unsupported force
values set a persistent group error; a failed snapshot rejects the run. Individual
populations, local sums and cumulative group sums are bounded to 1e30 to keep
intermediate FP32 additions representable. Native/WASM retain their f64 force
sums; GPU arithmetic does not promise bit identity.

`warmupSteps=W` excludes steps 1 through W from force history and variance
stopping. The solver reads and clears once at W even when it is not a sample
multiple; subsequent sampling still occurs at absolute multiples of
`forceSampleEvery` and at the final step, using the actual number of included
steps. A run ending at W keeps its last warmup block in the summary, with empty
history and no convergence claim. A resolved model's automatic reference area
is its projected voxel area times dx², without a physical area floor. Explicit
positive finite user areas are preserved; only the empty-channel function path
retains its existing placeholder area.

## Explicit wind-tunnel ground

`parameters.ground?: {mode:'stationary'|'moving',clearanceM:number}` enables an
adiabatic no-slip yMin plane; clearance must be finite and nonnegative. Moving
ground follows +x at the actual inlet speed, even when a fan sets a faster unit
reference. Other side walls retain `wallCondition`. Omitting ground preserves
the centered placement and original wall setting.

`createLbmModelTransform`, exported from the browser-safe `d3q19` subpath, is
shared by mesh voxelization, attached fan placement and thermal-region inverse
mapping. Its `point` and `bounds.min/max` are in lattice geometry coordinates:
cell centers are index+0.5, and the ground is y=0. `groundClearanceCells` aligns
the lowest actual rotated mesh vertex to clearanceM/dx, not a rotated bounding-box
corner. Every mode rejects a complete rotated model outside the physical domain
[0,nx]×[0,ny]×[0,nz], reporting the offending axis and bounds; no silent clipping
or rescaling is performed. Contact with domain endpoints, including y=0, remains
valid. This containment check is not a domain-size or wall-resolution accuracy
certificate, and surface voxelization may still mark a boundary cell. Voxels may
occupy y=0; no hidden one-cell gap is inserted. Voxel resolution still limits the
represented gap and geometry accuracy. Original-source `min/max` remain available
for normalized component coordinates.

Direct transforms require a positive integer grid with supported cell count,
positive finite characteristic cell count, finite angle, nonempty finite xyz
triples and positive finite source X span. Degenerate X geometry has no fallback
scale. Angles are reduced modulo 360 degrees; exact quarter turns use exact
0/±1 rotation coefficients so domain endpoints retain their surface voxels.
Nonempty voxelization validates the transform before allocating/growing
WASM buffers. The low-level completely empty mesh still returns zero flags;
product preparation rejects any non-null geometry that resolves zero solid
voxels, including a valid closed mesh too thin for the chosen grid. A null
geometry retains the existing empty-channel function path. These checks do not
repair topology or certify watertight CAD models.

Prepared `groundVelocityLattice` and the solver option preserve explicit zero.
Rust native and WASM use the same `ground_velocity: Option<f64>`; WebGPU uses
the same bounce-back equation in FP32. Ground wins at yMin/z corners, while the
x inlet reset and pressure-outlet reconstruction remains the final boundary operation.
Ground force is excluded from model drag/lift; its heat boundary is insulated
without viscous dissipation heating. These short-step capabilities do not certify
automotive drag or high-Reynolds convergence.

Consumers infer `LBM_GROUND_FEATURE='lbm-ground-v1'` using `requiredLbmFeatures(spec)`
and match actual executor features. Ground results save that feature as 1 together
with `derived.groundMode`, `groundClearanceM` and `groundVelocityMps`. Existing
thermal feature inference uses the same function; its old name is removed.

## Conservative thermal WebGPU

`D3Q19Solver` accepts the existing `ThermalUnits['thermal']` configuration for
both `fixed-temperature` and `solid-power`. Rust native and WASM remain the same
ABI11 mixed-precision implementation. WebGPU is a separate, explicit **FP32**
hardware backend for the same discrete equations; it does not execute the Rust
source and does not promise bit identity. WGSL supports
[f32/f16 floating-point types](https://gpuweb.github.io/gpuweb/wgsl/#floating-point-types),
[integer atomics](https://gpuweb.github.io/gpuweb/wgsl/#atomic-types), and permits
[floating-point reassociation/fusion](https://gpuweb.github.io/gpuweb/wgsl/#floating-point-evaluation).

`await solver.step()` is required for thermal steps. `getThermalStats()` is null
until a step succeeds; a numerical failure discards the run and prevents partial
results. `runBatchLbm` awaits steps, emits the existing `LbmThermalResult` energy
account, `derived.precision='float32'`, and the original physical Celsius metadata.
Power, boundary energy and residual are summed; peak residual and substep count
use the per-step maximum; energy and spatial temperature maxima describe the
final field. `visualize`/`readVelocity` use completed-step macros in all modes.
This corrects the previous one-step lag in isothermal GPU displays. Free-slip
transport preserves tangential displacement and reflects only crossed wall
normals, including y/z corners. The old D3Q7 path is not present.

Each step collides and streams D3Q19, then derives actual mass exchanges from
post-collision populations. Cells gather direct and specular D3Q19 links from
immutable populations and temperatures. Both endpoints evaluate the same
canonically ordered `(cell,direction)` pair with upwind sensible enthalpy and
apply opposite signs; reflected links cannot use the old nine-direction
indexing. Cells verify their mass against completed flow populations. The old
advection-link cache/pass is removed; only the three conduction faces per cell
need a flux buffer. Inlet/outlet
mass exchanges and the ambient inlet thermostat contribute to the boundary
energy account; closed walls do not create mass. Conduction uses one cached
harmonic-conductance flux per positive-axis face. Both adjacent cells consume the
same flux with opposite signs. Fixed walls use half-cell reservoir conductance;
solid cells receive their material’s `P*dt/materialCellCount` over the conduction substeps. Completed
macros apply fan and Kelvin buoyancy in one half-force correction.

The outgoing advective mass fraction is limited to 0.9. Conduction chooses
`ceil(max(dt*sum(G)/(0.9*mass*cp)))`, at least one and at most the configured
`maxSubsteps` (1–4096). Unsupported limits fail explicitly. GPU reductions report
energy before/after, power and reservoir contributions, residual, temperature
maxima, and failure bits. Workgroup reductions handle partial groups; global
phases use separate dispatches. Each thermal step maps only two 64-byte control
blocks. No field is copied to the CPU for thermal iteration. Full display/velocity
readback occurs only when explicitly requested, normally at the end of a batch.

Admission requires eight storage bindings, device-supported buffer/dispatch
sizes, dimensions at least 3 and at most 2^24 total cells. Lattice tau must be
between .505 and 1e10 and speed below .2. Positive physical coefficients and
initial mass/capacity/conductance must remain within 1e-20–1e20; nonzero source
energy per cell has the same range. Runtime density is limited to 1e-6–1e6,
capacity to 1e-20–1e26, energy per cell to ±1e20 J and temperature delta to ±1e6 K,
with absolute temperature above zero Kelvin. Runtime checks also reject inconsistent
mass, excessive advection/conduction CFL, non-finite state, unresolved coefficients,
and integer force-accumulator overflow. These are numerical safety limits, not
claims of physically useful accuracy across the entire interval. No temperatures
are clipped to a preferred visual range.

Storage is approximately `276*N` bytes plus `32*ceil(N/64)` bytes of reduction
scratch and small control buffers: about 138 MiB for the fast grid, 270 MiB for
standard and 427 MiB for fine before driver overhead. The largest single buffers
are 76*N bytes (flow populations) and 72*N bytes (link cache). Two host/device
synchronization points per step and two dispatches per conduction substep can
limit speed; large thermal substep counts can dominate. Hardware throughput and
large-grid convergence have not been benchmarked or certified here.

Tiny, opt-in real GPU checks use an already-installed Playwright module; this
repository does not install a browser dependency:

```sh
npm run build -w @w-sim/solvers-lbm
W_SIM_PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs node scripts/check-lbm-thermal-gpu.mjs
```

The check runs twelve 60-cell thermal cases for three steps and four isothermal/fan
cases for five steps against compiled native Rust, plus five failure/lifecycle
checks. It covers zero-power uniform temperature, an isolated solid with analytic
`deltaT=P*t/(mass*cp)`, heterogeneous interfaces, multiple conduction substeps,
fixed-temperature walls, nonzero inlet/outlet, no-slip and free-slip corners.
It also checks that each step copies only the two control blocks. Native/WASM
ABI checks include the asymmetric free-slip regression separately.

The GPU test tolerances are absolute plus relative: flow/display `2e-6 + 2e-5*abs(ref)`,
cell energy `2e-9 J + 3e-5*abs(ref)`, temperature delta `3e-5 K + 3e-5*abs(ref)`,
energy/boundary totals `5e-9 J + 3e-5*abs(ref)`, source `1e-12 J + 2e-6*abs(ref)`.
Residual is bounded by `5e-9 J + 5e-6*(abs(energy)+abs(boundary))` in these fixtures.
These small-case regression tolerances are not a general engineering error bound.
The verified adapter was Chromium SwiftShader (software Dawn); this verifies
shader execution and numerical agreement, not hardware GPU performance.


`solid-power` additionally accepts up to 16 material regions through
`parameters.thermalRegions`; the default-only model remains unchanged. Prepared
`thermal.materials` maps flags 5–20 to `{density,specificHeat,conductivity,totalPowerW}`.
Flag4 retains the default material and its own total power. Each regional power
is distributed only among that region's resolved solid cells; default and region
powers are summed in the source ledger. Regions require positive finite material
properties and finite nonnegative power, with no overlap or empty resolved volume.

Region AABBs are normalized to the original model bounding box. The shared Rust
classifier transforms lattice cell centers back into that space, so changing
angle of attack rotates the actual region with the model. It neither expands
rotated AABBs nor changes geometry occupancy. Surface voxelization can occupy
cells whose centers fall outside the original model bounds. Even regions covering
all of `[0,1]³` leave these cells on the default material; their coordinates are
not clamped into a region. No extra cell array or file is introduced: WebGPU uses a small uniform material/contact table (1216 bytes total),
while using the existing heat/link buffers and harmonic interface flux loop.
Material-specific capacity/conductivity participate in the same CFL and FP32
admission checks. Resolved solid faces default to perfect contact. Optional `thermalContacts`
adds area-normalized pairwise resistance; radiation and unresolved gaps remain unsupported.

The four added GPU fixtures check default plus two regions, two regions without
default cells, isolated region-only heating, and zero-inlet natural convection
without a fan. They use the existing tolerances
and two-control-block check. On SwiftShader their largest observed cell-energy
absolute error was 2.77e-10 J and temperature-delta error 3.20e-8 K relative to
native Rust. These observations do not certify long-run or hardware performance.

`parameters.thermalContacts` contains at most 136 entries
`{first,second,resistanceM2KW}` for enabled `solid-power`. Indices 0=default and
1–16=regions; each unordered pair must be unique and share an actual voxel face.
R is finite and nonnegative in m² K/W. At R>0 the shared flux uses
`G=dx²/(dx/(2*k1)+R+dx/(2*k2))`; R=0 keeps the old expression and field bits.
Prepared `thermal.thermal.contacts` preserves the sparse entries. GPU checks R
and conductance are resolved in FP32; each step still reads two 64-byte controls.
The extra face classification at preparation/constructor time uses shared WASM.

Consumers must require `LBM_THERMAL_FEATURES` according to
`requiredLbmFeatures(spec)` rather than accepting `thermal=true` alone.
Current GPU thermal results include fixed numeric `derived[feature]=1` values
so Hosts can reject results from old executors that ignore the extension. The
package's shell descriptor remains a stub and does not advertise these features.

The shared kernel loader also exports the 2D Stable Fluids/thermal-convection
step and teaching helpers. They use ten persistent f32 fields with f64 arithmetic
in the same Rust implementation as native execution. The current ABI version is 8;
the loader requires `fluid_step` to reject older incomplete artifacts. Source
reservoirs, dye decay and temperature cooling run per physics step in Rust.
This 2D masked educational model is separate from the conservative 3D LBM heat
solver; see the core/ABI README for its exact ordering and capability boundary.

### LBM mass diagnostics

New LBM jobs/capabilities/results require `lbm-mass-balance-v1`; result
`lbmMassBalance` is optional only for reading older stored results. The scope
`internal-fluid-x` means fluid cells x=1..nx-2. It reports initial/final mass,
cumulative signed inlet (into volume) / outlet (out of volume) transport,
collision writeback change, sum of independent per-step balances and the
maximum absolute global step balance. Numerical x-boundary final mass and
signed inlet/outlet NEE replacement are separate. Every numeric field is kg;
these cumulative masses are not kg/s. Force warmup does not discard mass steps.

Rust/WASM accumulate actual f32 populations in f64. GPU uses FP32 local/group
reductions: collide measures input and collision change, stream measures real
crossing links and pre-NEE boundary masses, macros measures completed masses.
Boundary replacements are independently measured final-minus-streamed layer
sums. An additional 64-lane pass traverses group records once per actual step
and updates global R and max(abs(R)). It is **not** a field traversal and adds
no readback. The force snapshot adds only a 48-byte interval header; its
48-byte-per-group scratch remains on GPU. Collision adds a local reduction,
and the thermal macros path now reduces too. This has a measurable compute
cost; it is not advertised as a performance improvement.

The CPU result uses f64 sums; the GPU report has diagnostic reduction error.
The real-GPU short check independently pushes the raw post populations in JS
f64, compares measured mass/flux/collision/reconstruction against that oracle,
and derives bounds using gamma(n)=n*u/(1-n*u), u=2^-24, absolute population
sums, 19 local operations, 6 local tree levels, ceil(groups/64) striped
additions and 6 global levels (plus subtraction bounds). It also checks the
actual per-step global R/max against group records. A small residual within
this precision budget is not proof of resolved flow or global convergence.

A bounded before/after check against `67ec3f5` used the same inputs and three
independent pairs (A/B, B/A, A/B). On a fixed CPU, the 128×64×64 thermal fixture
for five steps measured medians 1093.10 ms before / 1122.47 ms after (+2.69%);
all pre-existing scientific outputs matched exactly. On Chromium SwiftShader,
a 48×24×24 thermal fixture for three steps measured 96.8 / 130.9 ms (+35.23%).
All six full-field buffers (`f`, `post`, velocity, density, heat state, display),
force components and thermal statistics were bit-identical in the latter check.
These short measurements isolate diagnostic overhead; they do not establish
hardware-GPU performance or a long-run accuracy claim. The optional operator
check `W_SIM_GPU_COMPARE_BASELINE=1` uses a preserved ignored
`.runtime/mass-balance-review/d3q19-before.js`; ordinary short GPU checks require
no baseline artifact. No full 11208-step calculation was repeated.

The isothermal step submits its five ordered passes in one command encoder and
one queue submission; the heat sequence is unchanged. Setting
`W_SIM_GPU_COMPARE_BASELINE=fields` reruns only the preserved before/after
isothermal field/force comparisons and ordinary tiny oracles, without another
performance run.
