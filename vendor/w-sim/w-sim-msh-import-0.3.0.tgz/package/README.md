# `@w-sim/msh-import`

This package parses an explicit subset of ASCII Gmsh `.msh` files and maps
admitted meshes to W-Sim structural `JobSpecV1` values. It does not run a
solver. Unsupported solution-affecting input fails closed in `diagnostics`.

The importer reads MSH 2.2 and MSH 4.x meshes, including physical names and
boundary groups. Linear tet4 (type 4) and hex8 (type 5) solids are supported.
Linear prism6 (type 6) and pyramid5 (type 7) solids are also admitted as
importer compatibility paths and converted to tet4 elements:

- Each prism6 is split into three tet4 elements using connectivity indices
  `[0,1,2,3]`, `[1,4,2,3]`, and `[2,4,5,3]`.
- Each pyramid5 is split into two tet4 elements across base diagonal 0–2,
  using `[0,1,2,4]` and `[0,2,3,4]`.
- Each hex8 is split into six tet4 elements along body diagonal 0–6.

These conversions approximate the source element stiffness and interpolation;
they do not preserve native prism, pyramid, or hex formulations and do not
claim numerical equivalence. They do not establish general Gmsh/vendor
compatibility or solver parity. Every converted element produces an
`approximation` diagnostic identifying its source type and tetrahedral split.
`unsupported` diagnostics make the result `ok: false`; approximation and note
diagnostics preserve an inspectable mapped spec.

Geometry admission checks the resulting tet4 pieces for finite, non-collapsed
volume. Prism pieces must have consistent orientation. Pyramid admission also
requires a coplanar quadrilateral base and nondegenerate split tets with
consistent orientation. Invalid source geometry fails closed. The mapper
also enforces the structural smoke-domain limits (96 nodes, 256 emitted
elements, and 288 translational DOFs).

The mesh supplies geometry and named groups only. Material, analysis
procedure, constraints, and loads must be provided to the mapper. It supports
one isotropic material, static or modal structural jobs, fixed physical groups,
and concentrated nodal loads assigned to physical groups. Distributed loads,
multiple materials, higher-order solids (including prism15/18 and pyramid14),
and other unsupported sections or element types are not imported. The input
must be ASCII; binary MSH is unsupported.

```ts
import { mshTextToJobSpec } from '@w-sim/msh-import'

const result = mshTextToJobSpec(meshText, {
  procedure: 'static',
  material: { E: 210e9, nu: 0.3 },
  boundaries: {
    FIXED: 'fixed',
    TIP_LOAD: ['load', [0, 0, -1000]],
  },
})

if (!result.ok) {
  // Inspect result.diagnostics (level, path, message).
} else {
  const jobSpec = result.spec
}
```
