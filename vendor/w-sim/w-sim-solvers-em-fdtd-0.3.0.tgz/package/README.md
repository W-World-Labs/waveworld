# `@w-sim/solvers-em-fdtd`

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |

Smoke: free-space c₀ / Z₀ analytic. See `docs/solvers/em-fdtd.md`.
