# `@w-sim/solvers-export-report`

Deterministic **export-report** runner for W-Sim.

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |
| **maturity** | `smoke` (scaffold + fixture export; not engineering-complete) |
| **JobKind** | `export-report` from `@w-sim/contracts` (`BUILTIN_JOB_KINDS`) — no local raw-string duplicate |
| **method** | `export-report-v1` |
| **precision** | float64 (digest / numeric formatting) |
| **targets** | node CPU reference |

## What this package does

- Admits `export-report` jobs via the shared `JobRunner` shape (`canRun` + `run`).
- Turns a validated **source result envelope** (plus optional artifact refs) into a **report bundle**:
  - JSON (stable key order)
  - CSV (summary/KPI table)
  - Markdown (human-readable report)
  - Manifest with checksums, units, solver provenance, warnings, convergence status
- Emits stable progress for each export phase.
- Supports **cancellation** (`AbortSignal`) between phases.
- Missing/partial source artifacts produce an explicit **partial** report (`completed-with-warnings` or `failed`) — never fabricated field values.
- Templates are **declarative section lists only** (no code execution, no filesystem, no network).

## Multi-family / multi-solver (after partition bounds)

| Export | Role |
|--------|------|
| `buildFamilySourceResult(family)` | Smoke `JobResultV1` for lbm / thermal / structural / em-fdtd / acoustics / md / path-experiment |
| `buildFamilyExportJobSpec(family)` | Single-family export job |
| `buildMultiSolverExportJobSpec()` | One job over N family sources (`parameters.sourceResults`) |
| `buildMultiSolverExportBundle(...)` | Pure multi-solver index (json/csv/md/manifest); job artifacts are index-level only |

Package claim-loop smoke settles once via contracts `applySettlement` (duplicate key idempotent; different key → `double_settlement`).

## Host-backed streaming (after multi-solver)

| Export | Role |
|--------|------|
| `streamFieldPartitions` | Sequential partition walk through a sink |
| `FieldPartitionSource` / `arrayFieldPartitionSource` | Host may page; smoke uses in-memory arrays |
| `CollectingFieldPartitionSink` | In-process JobResult collect |
| `DrainingFieldPartitionSink` | Host-double: O(1) retained body + checksum meta |
| `ENGINEERING_EXPORT_BOUNDS` / `selectExportBounds('engineering')` | Raised caps; peak still O(partition) |

## Multi-GB paging residual (after host-backed streaming)

| Export | Role |
|--------|------|
| `PAGING_EXPORT_BOUNDS` / `selectExportBounds('paging')` | Multi-GiB-scale total cells; peak still O(partition) |
| `lazyFieldPartitionSource` | Generator source (one row at a time) |
| `materializePartitionsToDisk` / `diskFieldPartitionSource` | Disk-backed page-in source |
| `DirectoryFieldPartitionSink` | Out-of-process-style drain to files + checksum verify |

## Object-store residual (after multi-GB paging)

| Export | Role |
|--------|------|
| `BlobStore` / `MemoryBlobStore` / `createFetchBlobStore` | Injectable key/value port; CI map or remote get/put |
| `materializePartitionsToBlob` / `blobFieldPartitionSource` | Page partition tables from blob keys |
| `BlobFieldPartitionSink` | Drain CSV bodies to keys; O(1) body + checksum verify |

## Report-bundle object-store residual (after object-store seam)

| Export | Role |
|--------|------|
| `putExportBundleToBlob` | Put each report part under a key + write `bundle-index.json` |
| `loadExportBundleFromBlob` / `verifyExportBundleInBlob` | Sequential reload + fail-closed checksum |
| `readExportBundleIndexFromBlob` | Parse stored index (`w-sim.export-report-blob/v1`) |

## Settlement-ready residual (after report-bundle blob packaging)

| Export | Role |
|--------|------|
| `exportBundleBlobIndexToSettlement` | O(1) settlement view (index digests + part refs; no bodies) |
| `exportBundleBlobSettlementKey` | Stable `applySettlement` key from jobId + indexChecksum |
| `putExportBundleToBlob({ idempotent, signal })` | Skip matching re-puts; cancel between parts |
| `loadExportBundleFromBlob({ formats, signal })` | Selective format load; cancel between gets |

## Residual after settlement blob (package JobResult → O(1) settle)

| Export | Role |
|--------|------|
| `exportPartsFromJobResult` | Recover parts from runner `derived.*Body` |
| `packageExportResultToBlob` | Put parts + return O(1) JobResult + settlement key |
| `toSettlementReadyJobResult` | Strip bodies; attach blob digests (pure) |

Host-double path: claim → run → `packageExportResultToBlob` → complete(O(1) result) → `applySettlement` once/idempotent/double_settlement.

## Residual after packageExportResultToBlob settlement (rehydrate O(1))

| Export | Role |
|--------|------|
| `settlementRefsFromJobResult` | Digests from O(1) result; reject residual bodies |
| `matchExportSettlementKey` | Pure jobId ↔ settlement key check |
| `readExportBundleIndexFromSettledResult` | Index load + fail-closed checksum |
| `loadExportBundleFromSettledResult` | Selective rehydrate from settled payload alone |
| `verifyExportSettlementInBlob` | Soft audit digests + part bodies vs store |

Host-double path: complete(O(1)) → later `loadExportBundleFromSettledResult` / `verifyExportSettlementInBlob` without fat bodies or `packed.index`.

## Residual after rehydrate settlement (body restore + receipt)

| Export | Role |
|--------|------|
| `applyExportPartsToJobResult` | Pure inverse of body strip (`derived.*Body` restore; fail-closed) |
| `rehydrateJobResultFromSettled` | Load + apply → fat JobResult from O(1) settled + BlobStore |
| `exportSettlementReceipt` | Pure Host-ledger receipt (no I/O, no bodies) |

Host-double path: multi-solver claim → package → complete(O(1)) → settle → later `rehydrateJobResultFromSettled` restores bodies; settlement plane stays O(1) until explicit restore.

## Residual after body-restore (download catalog + single-part + re-strip)

| Export | Role |
|--------|------|
| `filenameForReportFormat` | Stable download filenames |
| `exportDownloadDescriptorsFromSettled` | O(1) download catalog from settled + index (no bodies) |
| `loadExportPartFromSettled` | Single-part download; peak O(one body) |
| `stripExportBodiesFromJobResult` | Pure re-strip after temporary rehydrate |
| `exportArtifactsFromSettled` | Host `JobResultArtifact[]` meta without bodies |

Host-double path: claim → package → complete(O(1)) → settle → catalog / single-part download → optional temporary rehydrate + strip back to O(1).

## Residual after download-catalog (signed URL + serve + receipt + conditional + drain)

| Export | Role |
|--------|------|
| `ExportUrlSigner` / `createMemoryExportUrlSigner` | Injectable presign port; CI memory double |
| `exportSignedDownloadDescriptorsFromSettled` | O(1) settled → signed download catalog |
| `exportDownloadResponseHeaders` | Pure HTTP serve headers (ETag / Content-Disposition / Accept-Ranges) |
| `exportDownloadReceipt` | Pure Host ledger receipt (no bodies) |
| `loadExportPartFromSettledConditional` | Conditional GET; 304 without body when ETag matches |
| `drainExportPartsFromSettled` | Sequential multi-part drain; peak O(one body) |

Host-double path: claim → package → complete(O(1)) → settle → signed catalog → conditional revalidate → sequential drain.

## Residual after download-serve (HTTP Range + partial body + 416)

| Export | Role |
|--------|------|
| `parseExportBytesRange` | Pure single-range parse (`bytes=`; multi-range → 416) |
| `sliceExportUtf8ByByteRange` | Pure UTF-8 byte slice for 206 bodies |
| `exportDownloadRangeResponseHeaders` | Pure 206/416 headers (Content-Range) |
| `applyExportDownloadRange` | Pure apply Range to loaded body + descriptor |
| `loadExportPartFromSettledRange` | Settled single-part; 416 without body; 206 after checksum |

Host-double path: claim → package → complete(O(1)) → settle → sign → conditional → range resume (0-N then N+1-) → drain.

## Residual after range residual (multi-range multipart/byteranges)

| Export | Role |
|--------|------|
| `MAX_EXPORT_MULTI_RANGES` | Cap 16 segments / request |
| `parseExportBytesRanges` | Pure multi-range parse; any bad segment → 416 |
| `buildExportMultipartByterangesBody` | Pure multipart/byteranges wire body |
| `exportDownloadMultiRangeResponseHeaders` | Pure multi 206 / 416 headers |
| `applyExportDownloadMultiRange` | Pure apply multi-range (1→Content-Range, 2+→multipart) |
| `loadExportPartFromSettledMultiRange` | Settled multi-range; 416 without body; multipart after checksum |

Host-double path: claim → package → complete(O(1)) → settle → sign → conditional → multi-range → drain.

## Residual after multi-range (If-Range)

| Export | Role |
|--------|------|
| `exportDownloadIfRangeMatches` | Pure strong ETag If-Range (RFC 7233 §3.2); date form → false |
| `effectiveExportRangeHeader` | Pure: drop Range when If-Range fails → full body |
| `applyExportDownloadMultiRange` / `loadExportPartFromSettledMultiRange` | Accept `ifRange`; miss → full (never 416 on ignored Range) |

Host-double path: claim → package → complete(O(1)) → settle → conditional → multi-range+If-Range match → miss→full.

## Residual after If-Range (strong ETag + single-range If-Range + Accept-Ranges KPI)

| Export | Role |
|--------|------|
| `exportDownloadStrongEtag` | Pure strong quoted ETag; weak descriptor etag → checksum fallback |
| `exportDownloadAcceptRangesKpi` / `EXPORT_DOWNLOAD_ACCEPT_RANGES_KPI` | Pure Host KPI + header matrix guard (`Accept-Ranges: bytes`) |
| `applyExportDownloadRange` / `loadExportPartFromSettledRange` | Accept `ifRange`; miss/weak → full (never 416 on ignored Range) |

Host-double path: claim → package → complete(O(1)) → settle → conditional → single-range+If-Range match → miss→full.

## What it does not do (yet)

- Live product S3/R2/GCS SDK adapter + credentials (package ships injectables only).
- Binary/image plot generation (declarative `plots` section emits text sparklines + stats from `source.history` only).
- PDF generation.
- Recomputing solver physics or arbitrary template engines.
- Tuanliu production dispatch wiring / product Host HTTP claim+lease settlement e2e (package has host-double + `applySettlement` smoke, including blob-index settlement keys, package-to-blob O(1) complete, rehydrate-from-settled audit, body-restore round-trip, download-catalog / single-part residual, download-serve signed-URL / conditional / drain, range residual, multi-range residual, If-Range residual, strong-ETag/single-range If-Range/Accept-Ranges KPI residual, native range GET residual, HEAD range + Content-Length residual, OPTIONS method residual, CORS preflight residual, security/cache headers residual, Accept content-negotiation residual, Cache-Control / Vary residual after Accept, frame/referrer security headers residual after Vary, rate-limit 429 + Retry-After residual after Cache-Control Vary, CORP/Permissions-Policy residual after frame, Content-Digest honesty residual after CORP, Digest vs Content-MD5 dual honesty residual after Content-Digest, Repr-Digest honesty residual after Digest dual, Content-Length floor honesty residual after Repr-Digest, Content-Range parse floor honesty residual after Content-Length floor, Accept-Encoding identity floor honesty residual after Content-Range parse floor, ETag weak/strong dual floor honesty residual after Accept-Encoding identity floor, Last-Modified parse floor honesty residual after ETag dual floor, and Accept-Ranges bytes floor honesty residual after Last-Modified parse floor).
- Live family-runner e2e (fixtures are envelope-only; they do not invoke thermal/LBM/etc. runners).
## Residual after multi-range + If-Range (object-store native range GET)

| Export | Role |
|--------|------|
| `BlobStore.getTextRange` / `blobStoreSupportsNativeRange` | Optional native byte-range GET |
| `MemoryBlobStore.getTextRange` | CI native range counters |
| `createFetchBlobStore({ getRange })` | Inject remote Range handler |
| `buildExportMultipartByterangesFromSlices` | Multipart from segments |
| Settled range loaders | Prefer native peak O(segment); `forceFullBody` fallback |

## Residual after native range GET (HEAD range + Content-Length)

| Export | Role |
|--------|------|
| `exportDownloadContentLength` | Pure parse Content-Length (fail-closed) |
| `measureExportMultipartByterangesBytes` | Multipart wire length without bodies |
| `applyExportDownloadRangeHead` / `MultiRangeHead` | Pure HEAD apply (no body) |
| `headExportPartFromSettledRange` / `MultiRange` | Settled HEAD; peak = index only |

Host-double path: claim → package → complete(O(1)) → settle → HEAD range / multi-range (no getText) → Content-Length parity with GET.

## Residual after HEAD range (Content-Disposition attachment + filename*)

| Export | Role |
|--------|------|
| `exportDownloadContentDisposition` | RFC 6266/5987 attachment + `filename*` |
| `sanitizeExportDownloadFilename` / `encodeRfc5987AttrValue` | Path-strip + UTF-8 percent-encode |
| `exportDownloadContentDispositionKpi` | Host KPI `present: 1` on full/206/416/HEAD |

## Residual after HEAD range (OPTIONS method plane)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_ALLOW_METHODS` / `EXPORT_DOWNLOAD_OPTIONS_KPI` | `Allow: GET, HEAD, OPTIONS` + KPI |
| `exportDownloadOptionsResponseHeaders` / `exportDownloadOptionsKpi` | Pure OPTIONS headers (CL=0; optional CORS) |
| `applyExportDownloadOptions` | Pure OPTIONS apply (204, no body) |
| `optionsExportPartFromSettled` | Settled OPTIONS; peak = index only |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS (no getText) → Allow KPI.

## Residual after OPTIONS method plane (CORS preflight completeness)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CORS_*` + `EXPORT_DOWNLOAD_CORS_KPI` | Default Allow-Headers / Expose-Headers / Max-Age + KPI |
| `exportDownloadCorsPreflightHeaders` | OPTIONS Access-Control-* (Methods/Headers/Max-Age + Expose) |
| `exportDownloadCorsResponseHeaders` | GET/HEAD Allow-Origin + Expose-Headers (Content-Range) |
| `exportDownloadCorsKpi` | Host matrix: preflight completeness + simple response expose |
| Serve / range / apply `cors` opt-in | Full / 206 / 416 / HEAD expose Content-Range for browser JS |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS preflight CORS KPI → pure 206 with Expose-Headers.

## Residual after CORS preflight (security / cache headers)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CACHE_CONTROL` | Default `private, max-age=0, must-revalidate, no-transform` |
| `EXPORT_DOWNLOAD_X_CONTENT_TYPE_OPTIONS` | Constant `nosniff` |
| `exportDownloadCacheControl` | Pure Cache-Control; always ensures `no-transform` |
| `exportDownloadSecurityHeaders` | Pure Cache-Control + nosniff + frame/referrer set for OPTIONS + GET/HEAD |
| `exportDownloadSecurityHeadersKpi` | Host matrix: `nosniff` + `no-transform` on full / 206 / 416 / HEAD / OPTIONS |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS security KPI → full / 206 carry no-transform + nosniff.

## Residual after CORS preflight (Accept content-negotiation honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_VARY` / `EXPORT_DOWNLOAD_OFFERED_MEDIA_TYPES` / `EXPORT_DOWNLOAD_ACCEPT_ENCODING` | `Vary: Accept, Accept-Encoding`; offered types; identity-only |
| `parseExportAcceptHeader` / `exportDownloadMediaTypeMatches` | Pure Accept parse + media-range match |
| `negotiateExportDownloadAccept` / `AcceptEncoding` / `Content` | Content-Type + identity Accept-Encoding negotiation |
| `exportDownloadAcceptNegotiationKpi` / `EXPORT_DOWNLOAD_ACCEPT_NEGOTIATION_KPI` | Host KPI + Vary matrix guard |
| `exportDownloadNotAcceptableHeaders` | Pure 406 headers (CL=0, Vary) |
| apply / OPTIONS / HEAD `accept` + `acceptEncoding` | Opt-in → `not_acceptable` (406) when client rejects |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS Accept+CORS → 406 on reject → 206 with Vary after Accept ok.

## Residual after Accept content-negotiation (Cache-Control / Vary honesty)

| Export | Role |
|--------|------|
| `ExportDownloadCachePlane` | `full` / `partial_content` / `meta` serve planes |
| `EXPORT_DOWNLOAD_CACHE_CONTROL_FULL` / `_PARTIAL` / `_META` | Plane defaults (partial equals full — no looser 206 cache) |
| `exportDownloadCacheControlForPlane` | Pure plane-aware Cache-Control (+ no-transform override) |
| `exportDownloadCacheVaryKpi` / `EXPORT_DOWNLOAD_CACHE_VARY_KPI` | Joint Vary (Accept, Accept-Encoding) + Cache-Control matrix |
| Full / 206 / 416 / OPTIONS / 406 headers | Stamp plane default under shared `Vary` |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS meta CC+Vary → full vs 206 plane CC (partial matches full) under Vary.

## Residual after Cache-Control / Vary (frame / referrer security headers)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_X_FRAME_OPTIONS` | Constant `DENY` |
| `EXPORT_DOWNLOAD_REFERRER_POLICY` | Constant `no-referrer` |
| `EXPORT_DOWNLOAD_CONTENT_SECURITY_POLICY` | CSP-lite (`default-src` / `frame-ancestors` / `base-uri` / `form-action` none) |
| `exportDownloadFrameReferrerHeaders` | Pure X-Frame-Options + Referrer-Policy + CSP set |
| `exportDownloadFrameReferrerHeadersKpi` / `EXPORT_DOWNLOAD_FRAME_REFERRER_HEADERS_KPI` | Host matrix on full / 206 / 416 / HEAD / OPTIONS / 406 |
| `exportDownloadXFrameOptions` / `ReferrerPolicy` / `ContentSecurityPolicy` | Pure wire values |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS frame DENY + no-referrer + CSP-lite → 206 / 406 same; Accept / Range / If-Range unchanged.

## Residual after frame / referrer (CORP + Permissions-Policy)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CROSS_ORIGIN_RESOURCE_POLICY` | Constant `same-origin` |
| `EXPORT_DOWNLOAD_PERMISSIONS_POLICY` | Constant `camera=(), microphone=(), geolocation=(), payment=(), usb=()` |
| `exportDownloadCorpPermissionsHeaders` | Pure CORP + Permissions-Policy set |
| `exportDownloadCorpPermissionsHeadersKpi` / `EXPORT_DOWNLOAD_CORP_PERMISSIONS_HEADERS_KPI` | Host matrix on full / 206 / 416 / HEAD / OPTIONS / 406 / 429 |
| `exportDownloadCrossOriginResourcePolicy` / `exportDownloadPermissionsPolicy` | Pure wire values |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS CORP same-origin + Permissions-Policy → 206 / 406 same; Accept / Range / If-Range / CORS unchanged.

## Residual after CORP (Content-Digest honesty for artifacts)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CONTENT_DIGEST_ALG` | Constant `fnv1a-128` (package `digestInput`; never `sha-256`) |
| `EXPORT_DOWNLOAD_X_CHECKSUM_HEADER` | Legacy `X-Checksum-Sha256-Trunc` (same FNV hex value) |
| `exportDownloadContentDigest` / `parseExportDownloadContentDigest` | Pure wire `fnv1a-128=:<hex>:` + parse (fail closed on sha-256 claims) |
| `exportDownloadContentDigestHeaders` | Pure Content-Digest + RFC 3230 Digest dual + RFC 9530 Repr-Digest + legacy X-Checksum when checksum present; never Content-MD5 |
| `exportDownloadContentDigestKpi` / `EXPORT_DOWNLOAD_CONTENT_DIGEST_KPI` | Host matrix on full / 206 / 416 / multi; CORS expose lists Content-Digest |
| `EXPORT_DOWNLOAD_CORS_EXPOSE_HEADERS` | Includes `Content-Digest` (+ `Digest` dual + `Repr-Digest`) for browser JS integrity reads |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS CORS Expose Content-Digest → 206 stamps `Content-Digest: fnv1a-128=:<checksum>:` + legacy X-Checksum; CORP / Accept / Range / If-Range unchanged.

## Residual after Content-Digest (Digest vs Content-MD5 dual honesty)

| Export | Role |
|--------|------|
| `exportDownloadDigest` / `parseExportDownloadDigest` | Pure RFC 3230 wire `fnv1a-128=<hex>` + parse (fail closed on md5 / sha-256 claims) |
| `EXPORT_DOWNLOAD_CONTENT_MD5_OMITTED` | Constant `true` — Content-MD5 never stamped (would claim MD5 for FNV digests) |
| `exportDownloadDigestContentMd5DualKpi` / `EXPORT_DOWNLOAD_DIGEST_CONTENT_MD5_DUAL_KPI` | Host matrix: Digest dual matches Content-Digest; Content-MD5 absent; CORS lists Digest not Content-MD5 |
| `exportDownloadContentDigestHeaders` | Stamps Content-Digest + Digest dual + Repr-Digest + legacy X-Checksum; never Content-MD5 |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS CORS Expose Digest → 206 stamps `Digest: fnv1a-128=<checksum>` dual of Content-Digest; Content-MD5 omitted; Accept / Range / If-Range / CORP unchanged.

## Residual after Digest dual (Repr-Digest honesty for representations)

| Export | Role |
|--------|------|
| `exportDownloadReprDigest` / `parseExportDownloadReprDigest` | Pure RFC 9530 wire `fnv1a-128=:<hex>:` + parse (fail closed on sha-256 / classic Digest form) |
| `exportDownloadReprDigestKpi` / `EXPORT_DOWNLOAD_REPR_DIGEST_KPI` | Host matrix: Repr-Digest matches Content-Digest / Digest dual token on full / 206 / 416 / multi; CORS lists Repr-Digest |
| `exportDownloadContentDigestHeaders` | Also stamps `Repr-Digest` (selected representation = complete export part) |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS CORS Expose Repr-Digest → 206 stamps `Repr-Digest: fnv1a-128=:<checksum>:` (full representation); Accept / Range / If-Range / CORP unchanged.

## Residual after Repr-Digest (Content-Length floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CONTENT_LENGTH_FLOOR` | Constant `0` — Content-Length never negative |
| `exportDownloadContentLengthFloorKpi` / `EXPORT_DOWNLOAD_CONTENT_LENGTH_FLOOR_KPI` | Host matrix: CL present + ≥ floor; full/206 match expected bytes; meta/OPTIONS/416/406/429 → 0; optional body UTF-8 parity; CORS lists Content-Length |
| `exportDownloadContentLength` | Existing pure parse (fail-closed) reused by floor KPI |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS CL=0 → 206 CL=segment length; Repr-Digest / Accept / Range / If-Range / CORP unchanged.

## Residual after Content-Length floor (Content-Range parse floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_CONTENT_RANGE_UNIT` / `EXPORT_DOWNLOAD_CONTENT_RANGE_FLOOR` | `bytes` unit + numeric floor `0` |
| `exportDownloadContentRange` | Pure fail-closed parse: `bytes start-end/total` (206) or `bytes */total` (416) |
| `exportDownloadContentRangeFloorKpi` / `EXPORT_DOWNLOAD_CONTENT_RANGE_FLOOR_KPI` | Host matrix: 206 partial CR + CL length parity; 416 unsatisfiable; full/OPTIONS/multi/406/429 omit CR; CORS lists Content-Range |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS omit CR → 206 CR parse floor + CL parity; Content-Length / Repr-Digest / Accept / Range / If-Range unchanged.

## Residual after Content-Range parse floor (Accept-Encoding identity floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_ACCEPT_ENCODING_FLOOR` / `EXPORT_DOWNLOAD_FORBIDDEN_CONTENT_ENCODINGS` | Floor `identity`; forbidden `gzip` / `br` / `deflate` / `compress` / `zstd` |
| `exportDownloadContentEncoding` | Pure fail-closed parse: omit or `identity` only (never claim compressed without transform) |
| `exportDownloadAcceptEncodingFloorKpi` / `EXPORT_DOWNLOAD_ACCEPT_ENCODING_FLOOR_KPI` | Host matrix: CE omit/identity; `no-transform`; Vary Accept-Encoding; optional Accept-Encoding negotiate (identity refused → fail closed) |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS identity floor → 206 omits Content-Encoding + no-transform under Vary; Content-Range / Content-Length / Repr-Digest unchanged.

## Residual after Accept-Encoding identity floor (ETag weak/strong dual floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_ETAG_STRENGTH_FLOOR` | Constant `strong` — never stamp `W/…` on serve wire |
| `exportDownloadEtagWire` | Pure fail-closed parse: strong quoted ETag only (weak → throw) |
| `exportDownloadEtagDualFloorKpi` / `EXPORT_DOWNLOAD_ETAG_DUAL_FLOOR_KPI` | Host matrix: serve strong + match `exportDownloadStrongEtag`; weak descriptor → checksum; If-None-Match weak ok; If-Range strong only; OPTIONS/429/406 omit ETag; CORS lists ETag |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS omit ETag → 206 strong dual (weak If-None-Match ok / weak If-Range → full); Accept-Encoding identity floor / Content-Range unchanged.

## Residual after ETag dual floor (Last-Modified parse floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_LAST_MODIFIED_OMITTED` | Constant `true` — never stamp Last-Modified (ETag-only validators) |
| `exportDownloadLooksLikeHttpDate` / `exportDownloadLastModified` | Pure HTTP-date detect + fail-closed parse (omit default; garbage → throw) |
| `exportDownloadLastModifiedFloorKpi` / `EXPORT_DOWNLOAD_LAST_MODIFIED_FLOOR_KPI` | Host matrix: all planes omit LM; date-form If-Range fail closed → full body; ETag dual unchanged |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS omit LM → 206 omit LM + date-form If-Range → full; ETag dual / Accept-Encoding identity floor unchanged.

## Residual after Last-Modified parse floor (Accept-Ranges bytes floor honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_ACCEPT_RANGES_FLOOR` | Constant `bytes` — never advertise `none` or other range units |
| `exportDownloadAcceptRanges` | Pure fail-closed parse: Accept-Ranges must be exactly `bytes` |
| `exportDownloadAcceptRangesFloorKpi` / `EXPORT_DOWNLOAD_ACCEPT_RANGES_FLOOR_KPI` | Host matrix: all planes stamp bytes; unit matches Content-Range; CORS exposes Accept-Ranges; aligns with legacy Accept-Ranges KPI |

Host-double path: claim → package → complete(O(1)) → settle → OPTIONS Accept-Ranges: bytes → 206 Accept-Ranges: bytes; Last-Modified omit / ETag dual unchanged.

## Residual after Cache-Control / Vary (rate-limit 429 + Retry-After honesty)

| Export | Role |
|--------|------|
| `EXPORT_DOWNLOAD_RATE_LIMIT_STATUS` / `EXPORT_DOWNLOAD_RETRY_AFTER_DEFAULT_SEC` | `429` + default `60` s Retry-After |
| `exportDownloadRetryAfter` | Pure Retry-After wire (delta-seconds preferred; HTTP-date ok) |
| `exportDownloadTooManyRequestsHeaders` | Pure 429 headers (Retry-After required; meta CC; CL=0) |
| `applyExportDownloadRateLimit` | Pure Host rate-limit mock apply (no body; receipt `rate_limit`) |
| `exportDownloadRateLimitKpi` / `EXPORT_DOWNLOAD_RATE_LIMIT_KPI` | Host matrix: Retry-After present + meta Cache-Control / Vary |

Host-double path: claim → package → complete(O(1)) → settle → rate-limit mock → 429 + Retry-After (no getText) before serve.

## Bounds (defaults)

| Cap | Smoke (`DEFAULT_EXPORT_BOUNDS`) | Engineering | Paging |
|-----|----------------------------------|-------------|--------|
| maxSourceArtifacts | 64 | 256 | 1024 |
| maxArtifactBytes | 256 KiB | 16 MiB | 2 GiB |
| maxPartitions | 16 | 256 | 8192 |
| maxPartitionValues | 4096 | 65536 | 65536 |
| maxTotalPartitionValues | 16384 | 1048576 | 268435456 (≈2 GiB float64) |
| maxWallTimeMs | 5000 | 60000 | 300000 |
| maxMemoryMb (smokeBudget meta) | 256 | (runner uses selected bounds) | peak still O(partition) |

## Docs

- Package standard: [`docs/SOLVER_PACKAGE_STANDARD.md`](../../docs/SOLVER_PACKAGE_STANDARD.md)
- Golden / lifecycle harness: [`docs/solvers/golden-conformance.md`](../../docs/solvers/golden-conformance.md) · cases under `packages/solver-conformance/cases/export-report/` · `npm run test:golden -w @w-sim/solvers-export-report`
- Definition of Done: [`docs/SOLVER_DEFINITION_OF_DONE.md`](../../docs/SOLVER_DEFINITION_OF_DONE.md)
- Family notes: [`docs/solvers/export-report.md`](../../docs/solvers/export-report.md)

## Smoke

```bash
npm test -w @w-sim/solvers-export-report
# or from repo root:
npm test
```
