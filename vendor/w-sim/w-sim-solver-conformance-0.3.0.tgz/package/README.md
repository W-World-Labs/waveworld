# `@w-sim/solver-conformance`

Reusable **runner lifecycle harness** and **per-family golden-case** library for W-Sim solver packages.

- **Does** share: JobRunner lifecycle protocol, sealed case manifests, family-owned tolerance comparison, failure-class reporting (numerical vs lifecycle/fixture/infra).
- **Does not** share: meshes, field stores, stepping kernels, or a global numeric tolerance.

## Install / import

```ts
import {
  runRunnerLifecycle,
  evaluateGoldenCase,
  evaluateGoldenSuite,
  loadGoldenManifests,
  formatSuiteReport,
  type FamilyCaseAdapter,
} from '@w-sim/solver-conformance'
```

## Lifecycle matrix

`runRunnerLifecycle` exercises:

`success` · `progress` · `cancel-pre` · `cancel-mid` · `reject-canRun` · `failure` · `warning` · `artifact` · `serialization`

## Golden manifests

Committed under [`cases/`](./cases/):

```text
cases/<family>/{smoke,scheduled}/*.case.json
```

| Rule | Detail |
|------|--------|
| Sealed | `reference.sealed: true`, `regeneration.allowSilentRegenerate: false` |
| Tolerances | Explicit `abs`/`rel` + dimensional `unit` + `rationale` per numeric invariant |
| Bound invariants | `invariants[].op: lte/gte/lt/gt` → one-sided numeric bound (no golden value); default `eq` |
| Scaffold | `reference.kind: "scaffold"` → `pending-scaffold` (not a PR failure) |
| Tiers | **smoke** (PR) vs **scheduled** (nightly / `test:solvers:scheduled`) |

## Package adapter pattern

```ts
const adapter: FamilyCaseAdapter = {
  family: 'path-experiment',
  packageName: '@w-sim/solvers-path-experiment',
  createRunner: (opts) => createPathExperimentRunner(opts),
  resolveSpec: (m) => {
    if (m.inputs.fixtureId === 'path-smoke') return buildSmokeJobSpec()
    throw new Error(`unknown fixture ${m.inputs.fixtureId}`)
  },
}

const report = await evaluateGoldenSuite(
  loadGoldenManifests({ family: 'path-experiment', tier: 'smoke' }),
  adapter,
)
expect(report.ok).toBe(true)
```

## Scripts

| Script | Role |
|--------|------|
| `npm test -w @w-sim/solver-conformance` | Unit + case library validation |
| `npm run test:golden -w @w-sim/solver-conformance` | Golden infrastructure inventory |
| `npm run test:convergence -w @w-sim/solver-conformance` | Scheduled slot inventory |

Root wiring: `npm test` (vitest picks up this package), `npm run test:solvers:scheduled` runs per-package `test:golden` / `test:convergence` when defined.

## Cross-host parity (issue #11)

```ts
import {
  listCiSmokeReferenceJobs,
  runCrossHostParitySuite,
  assertParityReportOk,
  formatParityReport,
} from '@w-sim/solver-conformance'
```

Reference jobs + browser/backend adapters produce a machine-readable report that separates **contract parity** (lifecycle, schema, provenance, artifact shape) from **numerical parity** (family-owned KPI tolerances). Explicit host differences (`hostClass`, precision claims, platform) are recorded, not normalized away.

| Entry | Role |
|-------|------|
| `src/cross-host/` | Types, reference jobs, adapters, compare, report |
| `npm run test:parity` (repo root) | Lightweight CI subset |
| [`docs/CROSS_HOST_PARITY.md`](../../docs/CROSS_HOST_PARITY.md) | Contract vs numerical policy |
| [`examples/cross-host-parity.md`](../../examples/cross-host-parity.md) | Wiring sketch |

## Docs

- [`docs/solvers/golden-conformance.md`](../../docs/solvers/golden-conformance.md)
- [`docs/CROSS_HOST_PARITY.md`](../../docs/CROSS_HOST_PARITY.md)
- [`docs/SOLVER_PACKAGE_STANDARD.md`](../../docs/SOLVER_PACKAGE_STANDARD.md) §9
