# `@w-sim/solvers-thermal`

Float64 **CPU reference** thermal package for W-Sim.

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |
| **maturity** | `smoke` for all three kinds: steady FD, 1D Pe convection, IGBT RθJA lump; engineering residual #24 (historical internal reference) |
| **JobKinds** | `thermal-3d-steady`, `thermal-3d-convection`, `electro-thermal-igbt` from `@w-sim/contracts` |
| **capability id** | `w-sim-thermal-steady-cpu` / `…-convection-cpu` / `…-igbt-cpu` (non-stub) |
| **method** | `thermal-steady-fd-gs-v1` · `thermal-convection-1d-pe-v1` · `thermal-igbt-rthja-v1` |
| **precision** | float64 |
| **targets** | node CPU reference |

## What this package does

- Admits all three thermal built-in kinds via `canRun`.
- Runs **structured 1D/2D steady heat conduction** (constant isotropic \(k\)) with Gauss–Seidel FD.
- Runs **1D Pe advection–diffusion** analytic profile for `thermal-3d-convection`.
- Runs **RθJA single-lump** steady / optional RC transient for `electro-thermal-igbt` (S24c).
- Requires **explicit units** on steady inputs; rejects non-positive / non-finite conductivity.
- Validates boundary completeness and conflicting BCs (Dirichlet / Neumann / insulated / **Robin** S24f).
- Returns temperature extrema, heat flow, residual, energy imbalance, grid, iterations, convergence.
- Observes **cancellation** inside the iteration loop.
- Emits **field artifacts**; large grids do not inline unbounded temperature arrays in the result JSON.
- Analytical **1D slab** golden case with reviewed tolerance `1e-9`.
- **S24f Robin BC**: 1D Dirichlet–Robin analytic (`ROBIN_1D_TOLERANCE=1e-8`) + 2D Robin energy-balance smoke.
- **S24g Cauer ladder**: multi-layer grounded Cauer Rθ stack (`thermal-igbt-cauer-stack-v1`); n=1 matches Foster; n>1 transient ≠ Foster.
- **S24h Cauer residual**: steady node probes, RθJC=R₀, Zθ(t)→RθJA; not XL multiphysics.
- **S24i case residual**: RθCA=RθJA−RθJC, T_case probe + case residual; not XL multiphysics.
- **S24j partial Zθ residual**: ZθJC(t)→RθJC, ZθCA(t)→RθCA, ZθJA=ZθJC+ZθCA; not XL multiphysics.
- **S24k layer Zθ residual**: Zθ_i(t)=(T_i−T_{i+1})/P → R_i, Σ Zθ_i=ZθJA, bridge to ZθJC/ZθCA; not XL multiphysics.
- **S24l cum structure-function residual**: ZΣ_i=Σ_{k≤i} Zθ_k → RΣ_i, ZΣ_{n−1}≡ZθJA; not XL multiphysics.
- **S24m power-pulse / cool-down residual**: optional `pulseWidthS` heat-then-cool; coolDownResidual→0; n=1 Cauer≡Foster pulse; not XL multiphysics.
- **S24n Foster↔Cauer conversion residual**: Z(s)-preserving `fosterToCauerLayers` / `cauerToFosterLayers`; ΣR + max\|Z_F−Z_C\| residual; not XL multiphysics.
- **S24o multi-pulse duty residual**: rectangular `periodS`+`pulseWidthS`/`dutyCycle` train; meanHeatingResidual→P·d·RθJA; periodResidual→0; n=1 Cauer≡Foster; not XL multiphysics.
- **S24p duty residual**: Cauer `multiPulseDutyEdges` export + Foster n-branch meanHeating tighten (edge-split midpoint, `IGBT_DUTY_MEAN_TOLERANCE=1e-8`) + two-pulse asymmetric train KPI; not XL multiphysics.
- **S24q duty peak/ripple residual**: last-period peak/valley/ripple Zθ + `periodPeakResidual` / `periodRippleResidual` → 0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24r burst N-pulse+cool / duty RMS residual**: finite `burstCount` N periods then cool (`coolDownResidual`→0); last-period RMS Zθ/ΔTj + `periodRmsResidual`→0 + `rmsPowerW`=P√d; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24s duty crest/form factor residual**: last-period crest=peak/rms, form=rms/mean + electrical `1/√d` + `periodCrestResidual`/`periodFormResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24t duty utilization / peak-to-mean residual**: last-period util=mean/peak, peakToMean=peak/mean (=crest×form) + electrical `d`/`1/d` + `periodUtilResidual`/`periodPeakToMeanResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24u duty energy integral / cycle energy residual**: last-period ∫Zθ dt = meanZ·T, ∫ΔTj, electrical `cycleEnergyPowerJ`=P·d·T + `energyHeatingResidual`/`periodEnergyResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24v duty variance / std residual**: last-period var=rms²−mean², std=√var + electrical `P²·d·(1−d)` / `P·√(d(1−d))` + `periodVarResidual`/`periodStdResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24w duty skewness / excess kurtosis residual**: last-period Fisher skew=m3/σ³, excessKurt=m4/σ⁴−3 + electrical `(1−2d)/√(d(1−d))` + `periodSkewResidual`/`periodKurtResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24x duty CV / MAD residual**: last-period cv=σ/μ, mad=E[|Z−μ|] + electrical `√((1−d)/d)` / `2·P·d·(1−d)` + `periodCvResidual`/`periodMadResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24y duty IQR / median residual**: last-period iqr=Q3−Q1, median=Q50 + electrical two-point `Q_p` + `periodIqrResidual`/`periodMedianResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24z duty trimmed-mean / percentile-rank residual**: last-period α-trimmed mean (α=0.10) + percentile rank of mean + electrical two-point trim + `periodTrimmedMeanResidual`/`periodPercentileRankResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24aa duty Winsorized-mean / Shannon-entropy residual**: last-period α-Winsor mean (clamp tails, keep n) + discrete Shannon entropy + electrical `P·d` / `h₂(d)` + `periodWinsorizedMeanResidual`/`periodEntropyResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ab duty Gini / HPD residual**: last-period Gini of \|ΔTj\| + HPD mass-interval width of Zθ (m=0.90) + electrical `1−d` / atom-HPD + `periodGiniResidual`/`periodHpdResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ac duty Lorenz / concentration residual**: last-period Lorenz L(p) of \|ΔTj\| + Hoover (Robin Hood) concentration + electrical `1−d` / L50 + `periodHooverResidual`/`periodLorenzResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ad duty Theil-T / Atkinson residual**: last-period Theil T + Atkinson A_ε of \|ΔTj\| (ε=0.5) + electrical `−ln(d)` / `1−d` + `periodTheilResidual`/`periodAtkinsonResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ae duty Palma / GE(2) residual**: last-period Palma=(1−L90)/L40 + GE(2)=½ CV² of \|ΔTj\| + electrical `½(1−d)/d` / Palma for d>0.6 + `periodPalmaResidual`/`periodGe2Residual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24af duty Rényi-H₂ / KS-vs-rect residual**: last-period Rényi H₂=−log₂(Σp²) of |ΔTj| histogram + KS vs mean-matched rectangular duty ref + electrical `−log₂((1−d)²+d²)` / KS=0 + `periodRenyi2Residual`/`periodKsResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ag duty Tsallis-S₂ / CvM-vs-rect residual**: last-period Tsallis S₂=1−Σp² of |ΔTj| histogram + Cramér–von Mises mean (F−G)² vs mean-matched rectangular duty ref + electrical `2d(1−d)` / CvM=0 + `periodTsallis2Residual`/`periodCvmResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ah duty Hellinger / JS-vs-rect residual**: last-period Hellinger H=√(1−BC) of |ΔTj| histogram vs mean-matched rectangular duty ref + Jensen–Shannon bits + electrical Hellinger≡0 / JS≡0 + `periodHellingerResidual`/`periodJsResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ai duty Bhattacharyya / W₁-vs-rect residual**: last-period Bhattacharyya D_B=−ln(BC) (Hellinger dual via shared BC) of |ΔTj| histogram vs mean-matched rectangular duty ref + Wasserstein-1 earth-mover vs rect quantile coupling + electrical D_B≡0 / W₁≡0 + `periodBhattacharyyaResidual`/`periodW1Residual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24aj duty TV / KL-vs-rect residual**: last-period total-variation TV=½Σ|p−q| of |ΔTj| histogram vs mean-matched rectangular duty ref + KL₂(P‖Q) bits + electrical TV≡0 / KL≡0 + `periodTvResidual`/`periodKlResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24ak duty χ² / Jeffreys-vs-rect residual**: last-period Pearson χ²=Σ(p−q)²/q of |ΔTj| histogram vs mean-matched rectangular duty ref + Jeffreys J₂=KL₂(P‖Q)+KL₂(Q‖P) bits + electrical χ²≡0 / J≡0 + `periodChi2Residual`/`periodJeffreysResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24al duty Neyman-χ² / triangular-vs-rect residual**: last-period Neyman χ²_N=Σ(p−q)²/p of |ΔTj| histogram vs mean-matched rectangular duty ref + triangular Δ=Σ(p−q)²/(p+q) + electrical Neyman≡0 / Δ≡0 + `periodNeymanChi2Residual`/`periodTriangularResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24am duty Sym-χ² / squared-Hellinger-vs-rect residual**: last-period Symmetric χ²=χ²_P+χ²_N of |ΔTj| histogram vs mean-matched rectangular duty ref + Squared Hellinger H²=Σ(√p−√q)²=2(1−BC) + electrical Sym≡0 / H²≡0 + `periodSymChi2Residual`/`periodSquaredHellingerResidual`→0 at periodic steady; n=1 Cauer ≡ Foster; not XL multiphysics.
- **S24an duty LeCam / Clark-vs-rect residual** (after S24am, not XL multiphysics): last-period Le Cam L=½Σ(p−q)²/(p+q)∈[0,1] of |ΔTj| histogram vs mean-matched rectangular duty ref + Clark squared C²=Σ(p−q)²/(p+q)∈[0,2] + electrical L≡0 / C²≡0 + `periodLeCamResidual`/`periodClarkResidual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24ao duty Taneja / Kumar-Johnson-vs-rect residual** (after S24an, not XL multiphysics): last-period Taneja T=Σ((p+q)/2)ln((p+q)/(2√(pq))) of |ΔTj| histogram vs mean-matched rectangular duty ref + Kumar–Johnson KJ=Σ(p²−q²)²/(2(pq)^{3/2}) + electrical T≡0 / KJ≡0 + `periodTanejaResidual`/`periodKumarJohnsonResidual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24ap duty Jain-Srivastava K₀ / Dragomir-B₁-vs-rect residual** (after S24ao pure KPI, not XL multiphysics): last-period Jain–Srivastava K₀=Σ(p−q)²/√(pq) of |ΔTj| histogram vs mean-matched rectangular duty ref + Dragomir B₁=Σ(p−q)⁴/(pq)^{3/2} + electrical K₀≡0 / B₁≡0 + `periodJainSrivastavaResidual`/`periodDragomirB1Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24aq duty Dragomir-B₂ / B₃-vs-rect residual** (after S24ap pure KPI, not XL multiphysics): last-period Dragomir B₂=Σ(√p−√q)⁴/(p+q) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃=Σ(√p−√q)⁴/√(pq) + electrical B₂≡0 / B₃≡0 + `periodDragomirB2Residual`/`periodDragomirB3Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24ar duty Dragomir-B₄ / B₅-vs-rect residual** (after S24aq pure KPI, not XL multiphysics): last-period Dragomir B₄=Σ(p−q)²(√p−√q)²/((p+q)√(pq)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅=Σ(p−q)²(√p−√q)²/(pq) + electrical B₄≡0 / B₅≡0 + `periodDragomirB4Residual`/`periodDragomirB5Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24as duty Dragomir-B₆ / B₇-vs-rect residual** (after S24ar pure KPI, not XL multiphysics): last-period Dragomir B₆=Σ(p−q)⁴/(pq(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₇=Σ(√p−√q)⁴/(pq) + electrical B₆≡0 / B₇≡0 + `periodDragomirB6Residual`/`periodDragomirB7Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24at duty Dragomir-B₈ / B₉-vs-rect residual** (after S24as pure KPI, not XL multiphysics): last-period Dragomir B₈=Σ(p−q)⁴/((pq)^{3/2}(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₉=Σ(√p−√q)⁴/(pq)^{3/2} + electrical B₈≡0 / B₉≡0 + `periodDragomirB8Residual`/`periodDragomirB9Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24au duty Dragomir-B₁₀ / B₁₁-vs-rect residual** (after S24at pure KPI, not XL multiphysics): last-period Dragomir B₁₀=Σ(p−q)⁴/((pq)²(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₁₁=Σ(√p−√q)⁴/(pq)² + electrical B₁₀≡0 / B₁₁≡0 + `periodDragomirB10Residual`/`periodDragomirB11Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24av duty Dragomir-B₁₂ / B₁₃-vs-rect residual** (after S24au pure KPI, not XL multiphysics): last-period Dragomir B₁₂=Σ(p−q)⁴/((pq)³(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₁₃=Σ(√p−√q)⁴/(pq)³ + electrical B₁₂≡0 / B₁₃≡0 + `periodDragomirB12Residual`/`periodDragomirB13Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24aw duty Dragomir-B₁₄ / B₁₅-vs-rect residual** (after S24av pure KPI, not XL multiphysics): last-period Dragomir B₁₄=Σ(p−q)⁴/((pq)⁴(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₁₅=Σ(√p−√q)⁴/(pq)⁴ + electrical B₁₄≡0 / B₁₅≡0 + `periodDragomirB14Residual`/`periodDragomirB15Residual`→0 at periodic steady; n=1 Cauer ≡ Foster.
- **S24ax duty Dragomir-B₁₆ / B₁₇-vs-rect residual** (after S24aw pure KPI, not XL multiphysics): last-period Dragomir B₁₆=Σ(p−q)⁴/((pq)⁵(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₁₇=Σ(√p−√q)⁴/(pq)⁵ + electrical B₁₆≡0 / B₁₇≡0 + `periodDragomirB16Residual`/`periodDragomirB17Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24ax: duty Dragomir B₁₆/B₁₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24ay duty Dragomir-B₁₈ / B₁₉-vs-rect residual** (after S24ax pure KPI, not XL multiphysics): last-period Dragomir B₁₈=Σ(p−q)⁴/((pq)⁶(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₁₉=Σ(√p−√q)⁴/(pq)⁶ + electrical B₁₈≡0 / B₁₉≡0 + `periodDragomirB18Residual`/`periodDragomirB19Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24ay: duty Dragomir B₁₈/B₁₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24az duty Dragomir-B₂₀ / B₂₁-vs-rect residual** (after S24ay pure KPI, not XL multiphysics): last-period Dragomir B₂₀=Σ(p−q)⁴/((pq)⁷(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₂₁=Σ(√p−√q)⁴/(pq)⁷ + electrical B₂₀≡0 / B₂₁≡0 + `periodDragomirB20Residual`/`periodDragomirB21Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24az: duty Dragomir B₂₀/B₂₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24ba duty Dragomir-B₂₂ / B₂₃-vs-rect residual** (after S24az pure KPI, not XL multiphysics): last-period Dragomir B₂₂=Σ(p−q)⁴/((pq)⁸(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₂₃=Σ(√p−√q)⁴/(pq)⁸ + electrical B₂₂≡0 / B₂₃≡0 + `periodDragomirB22Residual`/`periodDragomirB23Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24ba: duty Dragomir B₂₂/B₂₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bb duty Dragomir-B₂₄ / B₂₅-vs-rect residual** (after S24ba pure KPI, not XL multiphysics): last-period Dragomir B₂₄=Σ(p−q)⁴/((pq)⁹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₂₅=Σ(√p−√q)⁴/(pq)⁹ + electrical B₂₄≡0 / B₂₅≡0 + `periodDragomirB24Residual`/`periodDragomirB25Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bb: duty Dragomir B₂₄/B₂₅-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bc duty Dragomir-B₂₆ / B₂₇-vs-rect residual** (after S24bb pure KPI, not XL multiphysics): last-period Dragomir B₂₆=Σ(p−q)⁴/((pq)¹⁰(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₂₇=Σ(√p−√q)⁴/(pq)¹⁰ + electrical B₂₆≡0 / B₂₇≡0 + `periodDragomirB26Residual`/`periodDragomirB27Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bc: duty Dragomir B₂₆/B₂₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bd duty Dragomir-B₂₈ / B₂₉-vs-rect residual** (after S24bc pure KPI, not XL multiphysics): last-period Dragomir B₂₈=Σ(p−q)⁴/((pq)¹¹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₂₉=Σ(√p−√q)⁴/(pq)¹¹ + electrical B₂₈≡0 / B₂₉≡0 + `periodDragomirB28Residual`/`periodDragomirB29Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bd: duty Dragomir B₂₈/B₂₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24be duty Dragomir-B₃₀ / B₃₁-vs-rect residual** (after S24bd pure KPI, not XL multiphysics): last-period Dragomir B₃₀=Σ(p−q)⁴/((pq)¹²(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃₁=Σ(√p−√q)⁴/(pq)¹² + electrical B₃₀≡0 / B₃₁≡0 + `periodDragomirB30Residual`/`periodDragomirB31Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24be: duty Dragomir B₃₀/B₃₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bf duty Dragomir-B₃₂ / B₃₃-vs-rect residual** (after S24be pure KPI, not XL multiphysics): last-period Dragomir B₃₂=Σ(p−q)⁴/((pq)¹³(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃₃=Σ(√p−√q)⁴/(pq)¹³ + electrical B₃₂≡0 / B₃₃≡0 + `periodDragomirB32Residual`/`periodDragomirB33Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bf: duty Dragomir B₃₂/B₃₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bg duty Dragomir-B₃₄ / B₃₅-vs-rect residual** (after S24bf pure KPI, not XL multiphysics): last-period Dragomir B₃₄=Σ(p−q)⁴/((pq)¹⁴(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃₅=Σ(√p−√q)⁴/(pq)¹⁴ + electrical B₃₄≡0 / B₃₅≡0 + `periodDragomirB34Residual`/`periodDragomirB35Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bg: duty Dragomir B₃₄/B₃₅-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bh duty Dragomir-B₃₆ / B₃₇-vs-rect residual** (after S24bg pure KPI, not XL multiphysics): last-period Dragomir B₃₆=Σ(p−q)⁴/((pq)¹⁵(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃₇=Σ(√p−√q)⁴/(pq)¹⁵ + electrical B₃₆≡0 / B₃₇≡0 + `periodDragomirB36Residual`/`periodDragomirB37Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bh: duty Dragomir B₃₆/B₃₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bi duty Dragomir-B₃₈ / B₃₉-vs-rect residual** (after S24bh pure KPI, not XL multiphysics): last-period Dragomir B₃₈=Σ(p−q)⁴/((pq)¹⁶(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₃₉=Σ(√p−√q)⁴/(pq)¹⁶ + electrical B₃₈≡0 / B₃₉≡0 + `periodDragomirB38Residual`/`periodDragomirB39Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bi: duty Dragomir B₃₈/B₃₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bj duty Dragomir-B₄₀ / B₄₁-vs-rect residual** (after S24bi pure KPI, not XL multiphysics): last-period Dragomir B₄₀=Σ(p−q)⁴/((pq)¹⁷(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₄₁=Σ(√p−√q)⁴/(pq)¹⁷ + electrical B₄₀≡0 / B₄₁≡0 + `periodDragomirB40Residual`/`periodDragomirB41Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bj: duty Dragomir B₄₀/B₄₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bk duty Dragomir-B₄₂ / B₄₃-vs-rect residual** (after S24bj pure KPI, not XL multiphysics): last-period Dragomir B₄₂=Σ(p−q)⁴/((pq)¹⁸(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₄₃=Σ(√p−√q)⁴/(pq)¹⁸ + electrical B₄₂≡0 / B₄₃≡0 + `periodDragomirB42Residual`/`periodDragomirB43Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bk: duty Dragomir B₄₂/B₄₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bl duty Dragomir-B₄₄ / B₄₅-vs-rect residual** (after S24bk pure KPI, not XL multiphysics): last-period Dragomir B₄₄=Σ(p−q)⁴/((pq)¹⁹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₄₅=Σ(√p−√q)⁴/(pq)¹⁹ + electrical B₄₄≡0 / B₄₅≡0 + `periodDragomirB44Residual`/`periodDragomirB45Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bl: duty Dragomir B₄₄/B₄₅-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bm duty Dragomir-B₄₆ / B₄₇-vs-rect residual** (after S24bl pure KPI, not XL multiphysics): last-period Dragomir B₄₆=Σ(p−q)⁴/((pq)²⁰(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₄₇=Σ(√p−√q)⁴/(pq)²⁰ + electrical B₄₆≡0 / B₄₇≡0 + `periodDragomirB46Residual`/`periodDragomirB47Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bm: duty Dragomir B₄₆/B₄₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bn duty Dragomir-B₄₈ / B₄₉-vs-rect residual** (after S24bm pure KPI, not XL multiphysics): last-period Dragomir B₄₈=Σ(p−q)⁴/((pq)²¹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₄₉=Σ(√p−√q)⁴/(pq)²¹ + electrical B₄₈≡0 / B₄₉≡0 + `periodDragomirB48Residual`/`periodDragomirB49Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bn: duty Dragomir B₄₈/B₄₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bo duty Dragomir-B₅₀ / B₅₁-vs-rect residual** (after S24bn pure KPI, not XL multiphysics): last-period Dragomir B₅₀=Σ(p−q)⁴/((pq)²²(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅₁=Σ(√p−√q)⁴/(pq)²² + electrical B₅₀≡0 / B₅₁≡0 + `periodDragomirB50Residual`/`periodDragomirB51Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bo: duty Dragomir B₅₀/B₅₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bp duty Dragomir-B₅₂ / B₅₃-vs-rect residual** (after S24bo pure KPI, not XL multiphysics): last-period Dragomir B₅₂=Σ(p−q)⁴/((pq)²³(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅₃=Σ(√p−√q)⁴/(pq)²³ + electrical B₅₂≡0 / B₅₃≡0 + `periodDragomirB52Residual`/`periodDragomirB53Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bp: duty Dragomir B₅₂/B₅₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bq duty Dragomir-B₅₄ / B₅₅-vs-rect residual** (after S24bp pure KPI, not XL multiphysics): last-period Dragomir B₅₄=Σ(p−q)⁴/((pq)²⁴(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅₅=Σ(√p−√q)⁴/(pq)²⁴ + electrical B₅₄≡0 / B₅₅≡0 + `periodDragomirB54Residual`/`periodDragomirB55Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bq: duty Dragomir B₅₄/B₅₅-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24br duty Dragomir-B₅₆ / B₅₇-vs-rect residual** (after S24bq pure KPI, not XL multiphysics): last-period Dragomir B₅₆=Σ(p−q)⁴/((pq)²⁵(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅₇=Σ(√p−√q)⁴/(pq)²⁵ + electrical B₅₆≡0 / B₅₇≡0 + `periodDragomirB56Residual`/`periodDragomirB57Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24br: duty Dragomir B₅₆/B₅₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bs duty Dragomir-B₅₈ / B₅₉-vs-rect residual** (after S24br pure KPI, not XL multiphysics): last-period Dragomir B₅₈=Σ(p−q)⁴/((pq)²⁶(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₅₉=Σ(√p−√q)⁴/(pq)²⁶ + electrical B₅₈≡0 / B₅₉≡0 + `periodDragomirB58Residual`/`periodDragomirB59Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bs: duty Dragomir B₅₈/B₅₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- **S24bt duty Dragomir-B₆₀ / B₆₁-vs-rect residual** (after S24bs pure KPI, not XL multiphysics): last-period Dragomir B₆₀=Σ(p−q)⁴/((pq)²⁷(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₆₁=Σ(√p−√q)⁴/(pq)²⁷ + electrical B₆₀≡0 / B₆₁≡0 + `periodDragomirB60Residual`/`periodDragomirB61Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24bu duty Dragomir-B₆₂ / B₆₃-vs-rect residual** (after S24bt pure KPI, not XL multiphysics): last-period Dragomir B₆₂=Σ(p−q)⁴/((pq)²⁸(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₆₃=Σ(√p−√q)⁴/(pq)²⁸ + electrical B₆₂≡0 / B₆₃≡0 + `periodDragomirB62Residual`/`periodDragomirB63Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24bv duty Dragomir-B₆₄ / B₆₅-vs-rect residual** (after S24bu pure KPI, not XL multiphysics): last-period Dragomir B₆₄=Σ(p−q)⁴/((pq)²⁹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₆₅=Σ(√p−√q)⁴/(pq)²⁹ + electrical B₆₄≡0 / B₆₅≡0 + `periodDragomirB64Residual`/`periodDragomirB65Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24bw duty Dragomir-B₆₆ / B₆₇-vs-rect residual** (after S24bv pure KPI, not XL multiphysics): last-period Dragomir B₆₆=Σ(p−q)⁴/((pq)³⁰(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₆₇=Σ(√p−√q)⁴/(pq)³⁰ + electrical B₆₆≡0 / B₆₇≡0 + `periodDragomirB66Residual`/`periodDragomirB67Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24bx duty Dragomir-B₆₈ / B₆₉-vs-rect residual** (after S24bw pure KPI, not XL multiphysics): last-period Dragomir B₆₈=Σ(p−q)⁴/((pq)³¹(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₆₉=Σ(√p−√q)⁴/(pq)³¹ + electrical B₆₈≡0 / B₆₉≡0 + `periodDragomirB68Residual`/`periodDragomirB69Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24by duty Dragomir-B₇₀ / B₇₁-vs-rect residual** (after S24bx pure KPI, not XL multiphysics): last-period Dragomir B₇₀=Σ(p−q)⁴/((pq)³²(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₇₁=Σ(√p−√q)⁴/(pq)³² + electrical B₇₀≡0 / B₇₁≡0 + `periodDragomirB70Residual`/`periodDragomirB71Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24bz duty Dragomir-B₇₂ / B₇₃-vs-rect residual** (after S24by pure KPI, not XL multiphysics): last-period Dragomir B₇₂=Σ(p−q)⁴/((pq)³³(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₇₃=Σ(√p−√q)⁴/(pq)³³ + electrical B₇₂≡0 / B₇₃≡0 + `periodDragomirB72Residual`/`periodDragomirB73Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- **S24ca duty Dragomir-B₇₄ / B₇₅-vs-rect residual** (after S24bz pure KPI, not XL multiphysics): last-period Dragomir B₇₄=Σ(p−q)⁴/((pq)³⁴(p+q)) of |ΔTj| histogram vs mean-matched rectangular duty ref + B₇₅=Σ(√p−√q)⁴/(pq)³⁴ + electrical B₇₄≡0 / B₇₅≡0 + `periodDragomirB74Residual`/`periodDragomirB75Residual`→0 at periodic steady; n=1 Cauer ≡ Foster. Smoke KPI residual only — not engineering multiphysics DoD.
- S24bt: duty Dragomir B₆₀/B₆₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24bu: duty Dragomir B₆₂/B₆₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24bv: duty Dragomir B₆₄/B₆₅-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24bw: duty Dragomir B₆₆/B₆₇-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24bx: duty Dragomir B₆₈/B₆₉-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24by: duty Dragomir B₇₀/B₇₁-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24bz: duty Dragomir B₇₂/B₇₃-vs-rect pure KPI residual (smoke ≠ eng DoD)
- S24ca: duty Dragomir B₇₄/B₇₅-vs-rect pure KPI residual (smoke ≠ eng DoD)

## What it does not do (yet)

- Full 3D IGBT die/package multiphysics, nonlinear materials, unstructured meshes, GPU — residual on #24.
- Nonlinear / temperature-dependent properties for steady/convection engineering depth.
- Temperature-dependent Robin h(T).

## Units

| Quantity | Allowed labels |
|----------|----------------|
| length | `m` |
| temperature | `C` or `K` |
| conductivity | `W/(m·K)` (also `W/(m.K)`, `W/m/K`) |
| power | `W` |
| heat flux | `W/m^2` (also `W/m2`, `W·m^-2`) |

Coordinates: right-handed Cartesian; indexing 0-based nodal.

## Bounds (smoke)

| Cap | Value |
|-----|-------|
| max cells/axis | 128 |
| max iterations | 50 000 |
| wall time | 5 000 ms (`smokeBudget`) |
| memory | 256 MiB (documented) |
| inline field cells | ≤ 256 (else artifact-only) |

## Docs

- Family notes: [`docs/solvers/thermal.md`](../../docs/solvers/thermal.md)
- Package standard: [`docs/SOLVER_PACKAGE_STANDARD.md`](../../docs/SOLVER_PACKAGE_STANDARD.md)
- Matrix plan issue 10 / Gitea #23

## Smoke

```bash
npm test -w @w-sim/solvers-thermal
# or from repo root:
npm run test:solvers
```
