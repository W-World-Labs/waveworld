# `@w-sim/solvers-acoustics`

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track) |

Smoke: 1D plane-wave relation \(c = f \lambda\). See `docs/solvers/acoustics.md`.
