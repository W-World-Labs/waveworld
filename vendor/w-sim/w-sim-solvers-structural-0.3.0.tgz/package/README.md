# `@w-sim/solvers-structural`

Float64 CPU reference structural package (linear-elastic smoke: bar + beam2d + CST + tet4).

| Field | Value |
|-------|--------|
| **owner** | w-sim platform (S-solvers track · issue #25 / #26 / #38) |
| maturity | smoke (`structural-static`) |
| method | `structural-static-fem-bar-beam-cst-tet4-v1` |
| capability | `w-sim-structural-static-cpu` (non-stub) |
| precision | float64 |

See `docs/solvers/structural.md`. Tet4 is smoke-only (S26g-tet4); full 3D FEM residual remains on #26/#38.

The dense solver eliminates prescribed displacements and symmetrically scales
the free stiffness by its diagonal before checking numerical rank. Unrestrained
rigid modes fail with `singular_system`; a small force residual alone is not a
valid solution. `minPivot` is dimensionless for this scaled free system (1 when
all DOFs are prescribed), and is a diagnostic rather than a condition number.

Beam stress requires `sectionModulusM3 = I/c` for a section symmetric about its
bending neutral axis, supplied per element or as a parameter default. Recovery
uses the physical local end moments (including fixed-end UDL loads) and any
interior moment extremum, then combines axial and extreme-fibre bending stress.
Area and second moment alone do not determine the extreme-fibre distance.
Without a section modulus, displacement, axial stress and bending moments remain
available, but `summary.maxStressPa` is absent and
`derived.stressRecoveryStatus` is `section-modulus-required`. Beam reaction
forces (`maxReactionN`) and moments (`maxReactionMomentNm`) have distinct units.

Uniform distributed loads currently require the generated cantilever mesh;
explicit-mesh UDL inputs are rejected. This remains small-displacement, isotropic
linear-elastic analysis, without plasticity, contact, buckling or building-code
design checks. Plate analytic examples are not a shell FEM implementation.

FEM results store all actual fields in `JobResultV1.derived`, within the existing
96-node / 256-element / 288-DOF admission limit. There is no 48-DOF cutoff and no
fabricated artifact ID. `fieldInline: 1` means the field is present in the saved
result; the product can persist and download that JSON through its normal result
lifecycle. The Kirchhoff analytic path likewise returns its actual KPI summary
without advertising an uncreated file.

| CSV fields | Ordering and units |
| --- | --- |
| `nodeIdsCsv`, `nodePositionsCsv` | Original IDs, then x,y,z in m for each node in the same order; 2D z is 0. |
| `elementIdsCsv`, `elementConnectivityCsv` | Original element IDs and original node IDs per element: bar/beam 2, CST 3, tet4 4. |
| `dofNamesCsv` | Local order: bar `ux`; beam `ux,uy,rz`; CST `ux,uy`; tet4 `ux,uy,uz`. |
| `displacementCsv`, `reactionCsv` | Node-major, local order above. `displacementUnitsCsv` gives m or rad per DOF; `reactionUnitsCsv` gives N or N*m. |
| `elementAxialStressCsv`, `elementAxialStrainCsv` | Pa and dimensionless (`strainUnit: '1'`), in element-ID order. For continuum elements these are xx components. |
| `elementSxxCsv/SyyCsv/SzzCsv/SxyCsv/SyzCsv/SzxCsv` | Recovered continuum stress components, Pa. CST only has xx, yy, xy; `continuumKind` distinguishes plane stress/strain. |
| `elementExxCsv/EyyCsv/EzzCsv/GxyCsv/GyzCsv/GzxCsv` | Recovered continuum strains; G is engineering shear strain gamma. CST only has xx, yy, xy. |
| `elementBendingStressPaCsv` | Beam extreme-fibre bending stress magnitude, Pa. Requires each element's section modulus. |
| `elementBendingMoment1NmCsv`, `elementBendingMoment2NmCsv`, `elementMaxBendingMomentNmCsv` | Local beam end moments and maximum absolute moment including any interior extremum, N*m. |
| `elementLengthMCsv`, `elementAreaM2Csv`, `elementVolumeM3Csv` | Length m; CST area m²; tet4 volume m³. Length is line length for bar/beam, sqrt(2A) for CST and cbrt(6V) for tet4. |

All numeric CSV values are finite. Entirely unavailable optional columns are
omitted; partially unavailable values are empty CSV tokens, never a made-up zero.
For example, a beam with section modulus supplied only on some elements retains
those elements' stress values and leaves the others empty, while its aggregate
`maxStressPa` remains unavailable. Array order is explicit; IDs are not assumed
to be sequential indices. Missing analytical summary values are omitted rather
than encoded as NaN (which JSON would silently turn into null).
