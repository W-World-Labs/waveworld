# `@w-sim/ems-import`

This package parses the supported openEMS XML subset and maps admitted cases to
W-Sim `em-fdtd-3d` or `em-fdtd-sparams` JobSpecs. It does not execute a solver.
Unsupported features that affect the result fail closed in `diagnostics`;
approximations are reported alongside the emitted spec.

## S-parameter material slabs

The `em-fdtd-sparams` route accepts material boxes that span the complete
`y/z` cross-section and map to the solver's existing one-dimensional material
segments. Box bounds use the mapper's existing rounded, half-open cell
intervals. When slabs overlap, the box with the highest CSX `Priority` supplies
the material for each covered cell. Equal-priority overlaps with different
`Epsilon`, `Mue`, or `Kappa` fail closed because the source material is
ambiguous. Conductivity remains an approximation because the current line
solver accepts only `Epsilon` and `Mue` for each segment.

Partial cross-section boxes, non-box primitives, and material behavior outside
this one-dimensional mapping remain unsupported or explicitly diagnosed; this
does not add per-cell media to the 3D Yee solver.

## 3D PML thickness

On the `em-fdtd-3d` path, explicit openEMS `PML_N` thickness is mapped to
`pmlFraction` only when the mesh is uniform and every PML face has an explicit
positive cell count that implies the same fraction. That common fraction must
be inside the native solver's exclusive range `(0, 0.9)`. Mixed, incomplete,
or otherwise unrepresentable explicit thicknesses fail closed with a
diagnostic. A bare `PML` without `N` keeps the generic solver-default behavior
and emits a diagnostic. This documents the mapper's current behavior and does
not claim parity with openEMS or another vendor implementation.
